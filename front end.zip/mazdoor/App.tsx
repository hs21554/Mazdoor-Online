import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './src/Home';
import LaborSignup from './src/LaborSignup';
import CustomerSearch from './src/CustomerSearch';
import CustomerSearch2 from './src/CustomerSearch2';
import SearchResult from './src/SearchResult';
import CustomerSignup from './src/CustomerSignup';
import GetStarted from './src/GetStarted';
import SplashScreen from './src/SplashScreen';
import LaborLogin from './src/LaborLogin';
import LaborProfile from './src/LaborProfile';
import LaborHistory from './src/LaborHistory';
import LaborWorkDue from './src/LaborWorkDue';
import LaborOffers from './src/LaborOffers';
import CustomerLogin from './src/CustomerLogin';
import WorkProposal from './src/WorkProposal';
import CustomerProfile from './src/CustomerProfile';
import CustomerHistory from './src/CustomerHistory';
import Identification from './src/Identification';
import RatingPageCustomer from './src/RatingPageCustomer';
import Chat from './src/Chat';
import ChooseSkill from './src/ChooseSkill';
import BookNow from './src/BookNow';
import CustomerProfileupdate from './src/CustomerProfileupdate';
import LaborProfileupdate from './src/LaborProfileupdate';
import { Provider } from 'react-redux';
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import store from './store/store';
const persistor = persistStore(store);
const Stack = createNativeStackNavigator();

function App() {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name='SplashScreen' component={SplashScreen} />
            <Stack.Screen name='GetStarted' component={GetStarted} />
            <Stack.Screen name='Home' component={Home} />
            <Stack.Screen name='LaborSignup' component={LaborSignup} />
            <Stack.Screen name='LaborLogin' component={LaborLogin} />
            <Stack.Screen name='LaborProfile' component={LaborProfile} />
            <Stack.Screen
              name='LaborProfileupdate'
              component={LaborProfileupdate}
            />
            <Stack.Screen name='LaborHistory' component={LaborHistory} />
            <Stack.Screen name='LaborWorkDue' component={LaborWorkDue} />
            <Stack.Screen name='LaborOffers' component={LaborOffers} />
            <Stack.Screen name='CustomerSearch' component={CustomerSearch} />
            <Stack.Screen name='CustomerSearch2' component={CustomerSearch2} />
            <Stack.Screen name='CustomerSignup' component={CustomerSignup} />
            <Stack.Screen name='CustomerLogin' component={CustomerLogin} />
            <Stack.Screen name='CustomerProfile' component={CustomerProfile} />
            <Stack.Screen
              name='CustomerProfileupdate'
              component={CustomerProfileupdate}
            />
            <Stack.Screen name='CustomerHistory' component={CustomerHistory} />
            <Stack.Screen name='Identification' component={Identification} />
            <Stack.Screen name='SearchResult' component={SearchResult} />
            <Stack.Screen name='ChooseSkill' component={ChooseSkill} />
            <Stack.Screen name='WorkProposal' component={WorkProposal} />
            <Stack.Screen
              name='RatingPageCustomer'
              component={RatingPageCustomer}
            />
            <Stack.Screen name='Chat' component={Chat} />
            <Stack.Screen name='BookNow' component={BookNow} />
          </Stack.Navigator>
        </NavigationContainer>
      </PersistGate>
    </Provider>
  );
}

export default App;
