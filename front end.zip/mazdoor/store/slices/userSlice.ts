/* eslint-disable no-param-reassign */
/* eslint-disable import/prefer-default-export */
import { createSlice } from '@reduxjs/toolkit';
import { IUserState } from '../types/userData';

const initialState: IUserState = {
  data: null,
  uploadData: null,
  accessToken: '',
  typeManual: false,
  url: '',
  email: null,
  loading: false,
  error: null,
  gbg: {
    idfront: false,
    isBackRequired: false,
    idBack: false,
    poa: false,
    selfie: false,
  },
  currentData: null,
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    userSignin: (state, action) => {
      (state as any).accessToken = action.payload.accessToken;
    },

    userLogout: (state) => {
      state.data = null;
      state.accessToken = '';
      state.error = null;
      state.email = null;
      state.typeManual = false;
      state.loading = false;
      state.gbg = {};
      state.currentData = null;
    },
  },
});

export const { userSignin, userLogout } = userSlice.actions;
export default userSlice.reducer;
