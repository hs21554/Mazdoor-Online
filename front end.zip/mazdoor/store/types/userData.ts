export interface IUserData {
  directorVerified?: boolean;
  email: string;
  mainApplicant: {
    directors: [
      {
        firstName: string;
      },
    ];
  };
  checkApplicant: boolean;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  phoneNumber: string;
  jwttoken: string;
  balance: number;
  userName: string;
  details: {
    firstName: string;
    lastName: string;
    email: string;
    balance: number;
    dateOfBirth: string;
  };
  gbg: {
    steps: {
      idfront: { uploaded: boolean; isFailed: boolean };
      BackNotRequired: boolean;
      idback: {
        uploaded: boolean;
        isFailed: boolean;
        BackNotRequired: boolean;
      };
      poa: { uploaded: boolean; isFailed: boolean };
      selfie: { uploaded: boolean; isFailed: boolean };
    };
  };
  emailVerified: boolean;
  isVerified: boolean;
  mobileVerified: boolean;
  kycStatus: number;
  role: string;
  isBlocked: boolean;
  _id: string;
  token: string;
  workflowId: string | null;
  workFlowFailedMessage: string | null;
  passCode: string | null;
  isDeleted: boolean;
}
export interface IUserManualData {
  isFinished?: boolean;
  email: string;
  mainApplicant: {
    directors: [
      {
        firstName: string;
      },
    ];
  };
  checkApplicant: boolean;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  phoneNumber: string;
  jwttoken: string;
  balance: number;
  userName: string;
  details: {
    firstName: string;
    lastName: string;
    email: string;
    balance: number;
    dateOfBirth: string;
  };
  gbg: {
    steps: {
      idfront: { uploaded: boolean; isFailed: boolean };
      BackNotRequired: boolean;
      idback: {
        uploaded: boolean;
        isFailed: boolean;
        BackNotRequired: boolean;
      };
      poa: { uploaded: boolean; isFailed: boolean };
      selfie: { uploaded: boolean; isFailed: boolean };
    };
  };
  emailVerified: boolean;
  isVerified: boolean;
  mobileVerified: boolean;
  kycStatus: number;
  role: string;
  isBlocked: boolean;
  _id: string;
  token: string;
  workflowId: string | null;
  workFlowFailedMessage: string | null;
  passCode: string | null;
  isDeleted: boolean;
}
export interface IUserState {
  data: IUserData | null;
  url: string;
  uploadData: IUserData | null;
  accessToken: '';
  email: string | null;
  typeManual: boolean;
  loading: false;

  error: null;
  gbg: object;
  currentData: (IUserData | IUserManualData) | null;
}
