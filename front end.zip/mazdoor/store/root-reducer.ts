import { combineReducers } from 'redux';

import userReducer from './slices/userSlice';

const reducers = combineReducers({
  // slices
  user: userReducer,
  // userSteps: userStepsReducer,
  // API
});

export default reducers;
