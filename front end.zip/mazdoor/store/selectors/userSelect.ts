/* eslint-disable import/prefer-default-export */
import { RootState } from '../store';

export const selectUser = (state: RootState) => state.user;
