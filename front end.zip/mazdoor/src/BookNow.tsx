import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Modal } from 'react-native';
import { Icon, Avatar } from 'react-native-elements';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import { FontAwesome, Ionicons } from '@expo/vector-icons';


const BookingScreen = (props: { navigation: {
  goBack(): void; navigate: (arg0: string) => void; 
}; }) => {
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [selectedHour, setSelectedHour] = useState('');
  const [isFieldsFilled, setIsFieldsFilled] = useState(false);
  const [optionsModalVisible, setOptionsModalVisible] = useState(false);
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [address, setAddress] = useState('');
  const navigation = useNavigation();

  const handleBookPress = () => {
    if (isFieldsFilled) {
      props.navigation.navigate('CustomerSearch2');
    } else {
      setErrorMessage('Please fill all fields!');
      setErrorModalVisible(true);
    }
  };

  const handleChatPress = () => {
    props.navigation.navigate('Chat');
  };

  const handleConfirmDate = (date: { toDateString: () => React.SetStateAction<string>; }) => {
    setSelectedDate(date.toDateString());
    hideDatePicker();
    checkFields();
  };

  const handleConfirmTime = (time: { toLocaleTimeString: () => React.SetStateAction<string>; }) => {
    setSelectedTime(time.toLocaleTimeString());
    hideTimePicker();
    checkFields();
  };

  const checkFields = () => {
    if (selectedDate !== '' && selectedTime !== '' && selectedHour !== '' && address !== '') {
      setIsFieldsFilled(false);
    } else {
      setIsFieldsFilled(true);
    }
  };

  const showDatePicker = () => {
    setDatePickerVisibility(true);
    checkFields();
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const showTimePicker = () => {
    setTimePickerVisibility(true);
    checkFields();
  };

  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };

  const openOptionsModal = () => {
    setOptionsModalVisible(true);
    
  };

  const closeOptionsModal = () => {
    setOptionsModalVisible(false);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
     
      <TouchableOpacity onPress={() => props.navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
       
      </View>

      <Text style={styles.bookNow}>BOOK NOW</Text>

      

      <View style={styles.inputSection}>
        <View style={styles.inputContainer}>
          <Icon name="home" type="font-awesome" color="#000" />
          <TextInput
            style={styles.input}
            placeholder="Your Address"
            value={address}
            onChangeText={(text) => setAddress(text)}
          />
        </View>

        <TouchableOpacity style={styles.inputContainer} onPress={showDatePicker}>
          <Icon name="calendar" type="font-awesome" color="#000" />
          <TextInput
            style={styles.input}
            placeholder="Date"
            editable={false}
            value={selectedDate}
          />
        </TouchableOpacity>
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="date"
          onConfirm={handleConfirmDate}
          onCancel={hideDatePicker}
          minimumDate={new Date()} // Set minimum date to today
        />

        <View style={styles.inputContainer}>
          <Icon name="hourglass-start" type="font-awesome" color="#000" />
          <Picker
            style={styles.picker}
            selectedValue={selectedHour}
            onValueChange={(itemValue) => setSelectedHour(itemValue)}
          >
            <Picker.Item label="1 hour" value="1" />
            <Picker.Item label="2 hours" value="2" />
            <Picker.Item label="3 hours" value="3" />
            <Picker.Item label="4 hours" value="4" />
            <Picker.Item label="5 hours" value="5" />
            <Picker.Item label="6 hours" value="6" />
            <Picker.Item label="7 hours" value="7" />
            <Picker.Item label="8 hours" value="8" />
          </Picker>
        </View>

        <TouchableOpacity style={styles.inputContainer} onPress={showTimePicker}>
          <Icon name="clock-o" type="font-awesome" color="#000" />
          <TextInput
            style={styles.input}
            placeholder="Time"
            editable={false}
            value={selectedTime}
          />
        </TouchableOpacity>
        <DateTimePickerModal
          isVisible={isTimePickerVisible}
          mode="time"
          onConfirm={handleConfirmTime}
          onCancel={hideTimePicker}
        />
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={handleBookPress}>
          <Text style={styles.buttonText}>Book</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.buttonContainer1}>
        <TouchableOpacity style={styles.button1} onPress={handleChatPress}>
          <Text style={styles.buttonText}>Chat</Text>
        </TouchableOpacity>
      </View>
      <Modal
        animationType="slide"
        transparent={true}
        visible={errorModalVisible}
        onRequestClose={() => setErrorModalVisible(false)}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>{errorMessage}</Text>
            <TouchableOpacity
              style={{ ...styles.openButton, backgroundColor: '#00BF63' }}
              onPress={() => setErrorModalVisible(false)}
            >
              <Text style={styles.textStyle}>Ok</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        visible={optionsModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={closeOptionsModal}
      >
       
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  backButton: {
    position: 'absolute',
    left: -290,
    top: 30,
    zIndex: 1,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  openButton: {
    backgroundColor: "#F194FF",
    borderRadius: 20,
    paddingHorizontal: 25,
    paddingVertical: 8,
    elevation: 2,
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 30,
    right: -300,
    top: 20,
    paddingHorizontal: 16,
  },
  bookNow: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#333',
    marginVertical: 30,
    top:28,
  },
  
  workerInfo: {
    flex: 1,
  },
  workerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  workerSkill: {
    fontSize: 14,
    color: 'white',
  },
  workerRating: {
    fontSize: 14,
    color: 'white',
    marginTop: 4,
  },
  inputSection: {
    backgroundColor: '#fff',
    padding: 16,
    top:40,
    borderRadius: 10,
    marginBottom: 20,
    elevation: 1,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
    backgroundColor: '#f9f9f9',
  },
  input: {
    marginLeft: 10,
    fontSize: 16,
    flex: 1,
  },
  picker: {
    flex: 1,
    marginLeft: 10,
    color: '#000',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  buttonContainer1: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  button: {
    backgroundColor: '#00BF63',
    borderRadius: 20,
    height: 50,
    top:49,
    justifyContent: 'center',
    alignItems: 'center',
    width: '90%',
  },
  button1: {
    backgroundColor: '#4167B2',
    borderRadius: 20,
    height: 50,
    top:70,
    justifyContent: 'center',
    alignItems: 'center',
    width: '90%',
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  modalContainer: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOption: {
    backgroundColor: '#fff',
    width: '80%',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  modalOptionText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  modalOptionCancel: {
    backgroundColor: '#fff',
    width: '80%',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  modalOptionCancelText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff3d3d',
    textAlign: 'center',
  },
});

export default BookingScreen;
