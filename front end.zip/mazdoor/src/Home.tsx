import React from 'react';
import { View, StyleSheet, Text, Image, Dimensions, TouchableOpacity } from 'react-native';
import Background from './Background';
import { black, green } from './Constants';

const { width } = Dimensions.get('window');

const Home = (props: { navigation: { navigate: (arg0: string) => void; }; }) => {
  return (
    <Background>
      <View style={styles.container}>
      <Image source={require('./asset/Logo/Logo.jpg')} style={styles.image} />
      <Text style={styles.label}>Mazdoor Online</Text>
        <View style={styles.cardContainer}>
          <TouchableOpacity style={styles.card} onPress={() => props.navigation.navigate("LaborLogin")}>
            <Image source={require('./asset/MainPage/labor.png')} style={styles.image1} />
            <Text style={styles.label1}>Labor</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.card} onPress={() => props.navigation.navigate("CustomerSearch")}>
            <Image source={require('./asset/MainPage/find.png')} style={styles.image2} />
            <Text style={styles.label2}>Customer</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Background>
  );
}

const styles = StyleSheet.create({ 
  container: {
    flex: 1,
    backgroundColor: "#00BF63",
width:400,
  },
  cardContainer: {
    top: -20,
    alignItems: 'center',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    marginBottom: 20,
    width: width - 40,
    overflow: 'hidden',
    height:250,
  },
  image: {
    width: 270,
    height: 270,
    left:69,
    top:10,
    resizeMode: 'cover',
  },
  image1: {
    width: 170,
    height: 170,
    left:90,
    top:20,
    resizeMode: 'cover',
  },
  image2: {
    width: 170,
    height: 170,
    top:20,
    left:90,
    resizeMode: 'cover',
  },
  label: {
    fontSize: 26,
    color:'white',
    top:-60,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  label1: {
    fontSize: 20,
    paddingVertical: 25,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  label2: {
    fontSize: 20,
    top:25,
    textAlign: 'center',
    fontWeight: 'bold',
  },
});

export default Home;
