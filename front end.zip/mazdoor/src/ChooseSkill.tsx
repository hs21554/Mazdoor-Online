import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Dimensions, Modal } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons'; // Ensure you have expo/vector-icons installed
import DropdownMenu from './dropdownmenu';


const { width } = Dimensions.get('window');

interface CategoryItemProps {
  label: string;
  selectedSkill: string | null;
  imageSource: any;
}

const CategoryItem: React.FC<CategoryItemProps> = ({ label, selectedSkill, imageSource }) => {
  return (
    <View style={styles.categoryItem}>
      <Image source={imageSource} style={styles.categoryImage} />
      <Text style={[styles.categoryText, label === selectedSkill && styles.selectedText]}>{label}</Text>
    </View>
  );
};

const Chooseskill = (props: { navigation: {
  goBack(): void; navigate: (arg0: string, arg1: { selectedSkill: any; } | undefined) => void; 
}; }) => {
  const navigation = useNavigation();
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const [messageVisible, setMessageVisible] = useState(false);
  const [messageText, setMessageText] = useState('');

  const handleSkillSelection = (skill: string | null) => {
    setSelectedSkill(skill);
    if (skill) {
      setMessageText(`${skill} Selected!`);
      setMessageVisible(true);
      setTimeout(() => {
        setMessageVisible(false);
        props.navigation.navigate('WorkProposal', { selectedSkill: skill });
      }, 800); // Display the message for 1.5 seconds
    }
  };

  return (
    <View style={{ backgroundColor: '#fff', flex: 1 }}>
      <View style={styles.header}>
      <DropdownMenu navigation={navigation} />
        <TouchableOpacity onPress={() => props.navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.heading}>Select a skill</Text>
      </View>

      <Modal
        transparent={true}
        animationType="slide"
        visible={messageVisible}
        onRequestClose={() => setMessageVisible(false)}
      >
        <View style={styles.messageContainer}>
          <View style={styles.messageBox}>
            <Text style={styles.messageText}>{messageText}</Text>
          </View>
        </View>
      </Modal>

      <View style={styles.container}>
        <View style={styles.categoryRow}>
          <TouchableOpacity onPress={() => handleSkillSelection('Plumber/پلمبر')} activeOpacity={1}>
            <CategoryItem label="Plumber/پلمبر" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/plumber.png')} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleSkillSelection('Painter/پینٹر')} activeOpacity={1}>
            <CategoryItem label="Painter/پینٹر" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/painter.png')} />
          </TouchableOpacity>
        </View>
        <View style={styles.categoryRow}>
          <TouchableOpacity onPress={() => handleSkillSelection('Welder/ویلڈر')} activeOpacity={1}>
            <CategoryItem label="Welder/ویلڈر'" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/Welder.jpg')} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleSkillSelection('Mason/مستری')} activeOpacity={1}>
            <CategoryItem label="Mason/مستری" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/masons.png')} />
          </TouchableOpacity>
        </View>
        <View style={styles.categoryRow}>
          <TouchableOpacity onPress={() => handleSkillSelection('Mechanic/مکینک')} activeOpacity={1}>
            <CategoryItem label="Mechanic/مکینک" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/mechanic.png')} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleSkillSelection('Carpenter/بڑھئی')} activeOpacity={1}>
            <CategoryItem label="Carpenter/بڑھئی" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/carpenter.jpg')} />
          </TouchableOpacity>
        </View>
        <View style={styles.categoryRow}>
          <TouchableOpacity onPress={() => handleSkillSelection('Glazier/گلیزیئر')} activeOpacity={1}>
            <CategoryItem label="Glazier/گلیزیئر" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/glaziers.jpg')} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleSkillSelection('Digger/کھودنے والا')} activeOpacity={1}>
            <CategoryItem label="Digger/کھودنے والا" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/diggers.png')} />
          </TouchableOpacity>
        </View>
        <View style={styles.categoryRow}>
          <TouchableOpacity onPress={() => handleSkillSelection('Labourer/مزدور')} activeOpacity={1}>
            <CategoryItem label="Labourer/مزدور" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/labourer.png')} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleSkillSelection('Electrician/الیکٹریشن')} activeOpacity={1}>
            <CategoryItem label="Electrician/الیکٹریشن" selectedSkill={selectedSkill} imageSource={require('./asset/Skills/electrician.png')} />
          </TouchableOpacity>
        </View>
        <Image source={require('./asset/MainPage/lab.jpg')} style={styles.image} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 50,
    marginHorizontal: 0,
    paddingTop: 10,
    backgroundColor: '#00BF63',
    paddingVertical: 10,
    paddingHorizontal: 45,
  },
  heading: {
    color: 'white',
    fontSize: 25,
    left: -60,
    fontWeight: 'bold',
  },
  container: {
    flexDirection: 'column',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  categoryRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  categoryItem: {
    flexDirection: 'column',
    alignItems: 'center',
    marginVertical: 10,
  },
  categoryImage: {
    width: 36,
    height: 36,
  },
  categoryText: {
    color: 'black',
    fontSize: 12,
    marginLeft: 6,
  },
  selectedText: {
    paddingTop: 10,
    textDecorationLine: 'underline',
    marginLeft: 5,
  },
  image: {
    top: 50,
    width: width + 15,
    height: (width - 40) * 0.5,
    resizeMode: 'contain',
    marginVertical: 50,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  menuContainer: {
    backgroundColor: 'white',
    marginTop: 80,
    marginLeft: 20,
    borderRadius: 8,
    padding: 10,
    elevation: 2,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  menuItemText: {
    marginLeft: 10,
    fontSize: 16,
    color: 'black',
  },
  messageContainer: {
    flex: 1,
    top: 140,
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageBox: {
    backgroundColor: '#00BF63',
    padding: 20,
    borderRadius: 10,
    width: width * 0.8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  backButton: {
    position: 'absolute',
    left: 25,
    top: 23,
    zIndex: 1,
  },
  messageText: {
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});

export default Chooseskill ;
