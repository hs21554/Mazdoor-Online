import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, StyleSheet } from 'react-native';
import { Icon } from 'react-native-elements';

const DropdownMenu2 = (props: { navigation: { navigate: (arg0: any) => void; }; }) => {
  const [optionsModalVisible, setOptionsModalVisible] = useState(false);

  const openOptionsModal = () => {
    setOptionsModalVisible(true);
  };

  const closeOptionsModal = () => {
    setOptionsModalVisible(false);
  };

  const handleNavigation = (screen: string) => {
    props.navigation.navigate(screen);
    closeOptionsModal();
  };

  return (
    <View style={styles.menuContainer}>
      <TouchableOpacity onPress={openOptionsModal}>
        <Icon name="dots-three-vertical" type="entypo" color="white" size={24} />
      </TouchableOpacity>

      <Modal
        visible={optionsModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={closeOptionsModal}
      >
        <View style={styles.modalContainer}>
          <TouchableOpacity style={styles.modalOption} onPress={() => handleNavigation('CustomerProfile')}>
            <Text style={styles.modalOptionText}>Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalOption} onPress={() => handleNavigation('Chat')}>
            <Text style={styles.modalOptionText}>Chat</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalOption} onPress={() => handleNavigation('CustomerSearch2')}>
            <Text style={styles.modalOptionText}>Find Labor</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalOption} onPress={() => handleNavigation('CustomerHistory')}>
            <Text style={styles.modalOptionText}>History</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalOption} onPress={() => handleNavigation('Login')}>
            <Text style={styles.modalOptionlogoutText}>Log Out</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalOptionCancel} onPress={closeOptionsModal}>
            <Text style={styles.modalOptionCancelText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  menuContainer: {
    flexDirection: 'row',
    right: -320,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOption: {
    backgroundColor: '#fff',
    width: '80%',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  modalOptionText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  modalOptionCancel: {
    backgroundColor: '#fff',
    width: '80%',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  modalOptionCancelText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff3d3d',
    textAlign: 'center',
  },
  modalOptionlogoutText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff3d3d',
    textAlign: 'center',
  },
});

export default DropdownMenu2;
