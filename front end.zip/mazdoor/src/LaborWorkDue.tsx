import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image } from 'react-native';
import { FontAwesome,Ionicons } from '@expo/vector-icons';
import { white } from './Constants';
import DropdownMenu from './dropdownmenu';

const InfoItem = (props: { iconName: any; placeholder: any; }) => {
  const { iconName, placeholder } = props;
  return (
    <View style={styles.infoItem}>
      <View style={{ flexDirection: 'row', alignItems: 'center', width: 300, marginVertical: 5, top: -5 }}>
        <FontAwesome name={iconName} size={20} color={white} style={{ paddingHorizontal: 10 }} />
        <TextInput editable={false} placeholder={placeholder} placeholderTextColor={white} style={styles.input} />
      </View>
    </View>
  );
};

const LaborWorkDue = (props: { navigation: { navigate: (arg0: string) => void; goBack: () => void; }; }) => {
  const [selectedButton, setSelectedButton] = useState('Work Due');
  return (
    <View style={styles.container}>
  <View style={styles.header}>
        {/* Left aligned back button */}
        <TouchableOpacity onPress={() => props.navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        
        {/* dropdown list */}
        <DropdownMenu navigation={props.navigation} />


        {/* Centered header image */}
        <Image source={require('./asset/Logo/Logo.jpg')} style={styles.headerImage} />
        {/* Placeholder for center alignment */}
        <View style={{ flex: 1 }}></View>
        
        
      </View>
      <View style={styles.buttonContainer}>
        {/* Buttons */}
        <TouchableOpacity
          style={[styles.button, selectedButton === 'باقی کام' ? styles.selectedButton : null]}
          onPress={() => props.navigation.navigate('LaborWorkDue')}
        >
          <Text style={[styles.buttonText, selectedButton === 'باقی کام'? styles.selectedButtonText : null]}>Work Due</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, selectedButton === 'New Offers/نئی پیشکشیں' ? styles.selectedButton : null]}
          onPress={() => props.navigation.navigate('LaborOffers')}
        >
          <Text style={[styles.buttonText, selectedButton === 'New Offers' ? styles.selectedButtonText : null]}>New Offers</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, selectedButton === 'History/تاریخ' ? styles.selectedButton : null]}
          onPress={() => props.navigation.navigate('LaborHistory')}
        >
          <Text style={[styles.buttonText, selectedButton === 'History' ? styles.selectedButtonText : null]}>History</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.rectangleContainer}>
        <View style={styles.rectangle26}>
          <Text style={styles.workProposalText}>Work Due </Text>
          <View style={styles.infoContainer}>
          <InfoItem iconName="user" placeholder="Huzaifa" />
            <InfoItem iconName="address-book-o" placeholder="House # G-9 Officers Colony" />
            <InfoItem iconName="clock-o" placeholder="4:12 Pm" />
            <InfoItem iconName="calendar" placeholder="23-03-2024" />
            <InfoItem iconName="hourglass" placeholder="3 Hour" />
          </View>
        </View>
        <View style={styles.rectangle26}>
          <Text style={styles.workProposalText}>Work Due </Text>
          <View style={styles.infoContainer}>
           <InfoItem iconName="user" placeholder="Ali Khan" />
            <InfoItem iconName="address-book-o" placeholder="I-8 House # 332" />
            <InfoItem iconName="clock-o" placeholder="2:00 Pm" />
            <InfoItem iconName="calendar" placeholder="2-05-2024" />
            <InfoItem iconName="hourglass" placeholder="8 Hours" />
          </View>
        </View>
      </View>
      <View style={styles.footer}>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    backgroundColor: '#00BF63',
    width: 400,
    paddingTop: 10,
    paddingBottom: 10,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  headerText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  button: {
    backgroundColor: '#fff',
    paddingVertical: 8,
    marginTop: -10,
    borderWidth: 1,
    borderColor: 'black',
    elevation: 3,
    flex: 1,
  },
  buttonText: {
    textAlign: 'center',
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedButton: {
    backgroundColor: '#00BF63',
  },
  selectedButtonText: {
    color: 'white',
  },
  rectangleContainer: {
    alignItems: 'center',
    marginTop: 40,
  },
  rectangle26: {
    width: 302,
    height: 285,
    backgroundColor: '#00BF63',
    borderRadius: 28,
    marginBottom: 20,
    alignItems: 'center',
    paddingTop: 20,
  },
  workProposalText: {
    color: '#F5F5F5',
    fontSize: 25,
    fontWeight: '800',
    marginBottom: 20,
    textAlign: 'center',
  },
  infoContainer: {
    width: '100%',
    alignItems: 'flex-start',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 20,
  },
  input: {
    flex: 1,
    fontSize: 13,
    height: 28,
    color: white,
    paddingHorizontal: 10,
    backgroundColor: 'transparent',
  },
  footer: {
    backgroundColor: '#00BF63',
    width: 400,
    paddingTop: 40,
    paddingBottom: 10,
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  footerText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    marginLeft: 10,
    padding: 10,
  },
  headerImage: {
    width: 70,
    height: 40,
    right:-90,
    marginRight:50, // Add this line to center the image horizontally
},

});

export default LaborWorkDue;
