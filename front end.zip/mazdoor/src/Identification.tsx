import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { AntDesign } from '@expo/vector-icons'; // Importing AntDesign icons from Expo
import { useNavigation } from '@react-navigation/native'; // Import useNavigation hook from React Navigation

const Identification = (props: { navigation: { navigate: (arg0: string) => void; }; }) =>  {
  const navigation = useNavigation(); // Initializing navigation

  const handleBackPress = () => {
    // Implement your navigation logic here
    console.log('Back button pressed');
    navigation.goBack(); // Navigate to the previous screen
  };

  const handleDonePress = () => {
    // Implement your navigation logic here
    console.log('Done button pressed');
    props.navigation.navigate('LaborSignup'); // Navigate to the next screen
  };

  return (
    <View style={styles.container}>
      {/* Back button */}
      <TouchableOpacity onPress={handleBackPress} style={styles.backButton}>
        <AntDesign name="arrowleft" size={24} color="black" />
      </TouchableOpacity>
      
      <Text style={styles.title}>EMAIL VERIFICATION</Text>
      <View style={styles.imageContainer}>
        <Image
          style={styles.image}
          source={require('./asset/VerifyID/VerfiyPic.jpg')} 
        />
      </View>
      <View style={styles.centered}>
        <View style={styles.greenBox}>
          <Text style={styles.boxText}>
            Bring Your ID in front of you and take a photo as an example:{'\n\n'}
            The photo should clearly show the face and your driver's license.{'\n\n'}
            The photo must be taken in good light and in good quality.{'\n\n'}
            Photos in sunglasses are not allowed.
          </Text>
          <TouchableOpacity style={styles.button} onPress={handleDonePress}>
            <Text style={styles.buttonText}>DONE</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.footer}>
        <Text style={styles.footerText}></Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  backButton: {
    position: 'absolute',
    marginTop:30,
    top: 20,
    left: 20,
    zIndex: 1,
  },
  title: {
    color: 'black',
    fontSize: 20,
    paddingTop: 80,
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 20,
  },
  centered: {
    alignItems: 'center',
  },
  greenBox: {
    width: 319,
    backgroundColor: '#00BF63',
    borderRadius: 26,
    padding: 25,
    alignItems: 'center',
  },
  boxText: {
    color: 'white',
    fontSize: 15,
    fontWeight: 'normal',
    textAlign: 'justify',
    marginBottom: 10,
  },
  description: {
    color: 'black',
    fontSize: 15,
    fontWeight: 'normal',
    marginTop: 20,
    marginBottom: 20,
  },
  imageContainer: {
    width: 316,
    height: 197,
    overflow: 'hidden',
    borderRadius: 20,
    marginBottom: 20,
    alignSelf: 'center',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  button: {
    width: 122,
    height: 39,
    backgroundColor: 'white',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 5,
    marginLeft: 120,
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: '800',
  },
  footer: {
    marginTop: 50,
    backgroundColor: '#00BF63',
  right:50,
    width:700,
    alignItems: 'center',
  },
  footerText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Identification;
