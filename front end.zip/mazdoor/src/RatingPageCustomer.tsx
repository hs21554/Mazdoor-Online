import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image } from 'react-native';
import { FontAwesome,Ionicons  } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native'; // Importing the useNavigation hook
import { white } from './Constants';
import DropdownMenu2 from './dropdownmenuProfilec';

const InfoItem = (props: { iconName: any; placeholder: any; }) => {
  const { iconName, placeholder } = props;
  return (
    <View style={styles.infoItem}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 5 }}>
        <FontAwesome name={iconName} size={20} color={white} style={{ paddingHorizontal: 10 }} />
        <TextInput editable={false} placeholder={placeholder} placeholderTextColor={white} style={styles.input} />
      </View>
    </View>
  );
};

const RatingPageCustomer = (props: { navigation: {
  goBack(): void; navigate: (arg0: string) => void; 
}; }) =>  {
  const navigation = useNavigation(); // Using the useNavigation hook
  const [selectedButton, setSelectedButton] = useState('History');
  const [rating, setRating] = useState(0);
  const [showTextInput, setShowTextInput] = useState(false);
  const [comment, setComment] = useState('');

  useEffect(() => {
    // Additional code if needed when component mounts
  }, []);

  const handleStarPress = (index: number) => {
    setRating(index + 1);
  };

  const toggleTextInput = () => {
    setShowTextInput(!showTextInput);
  };

  

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        {/* dropdown list */}
        <DropdownMenu2 navigation={navigation} />
      <TouchableOpacity onPress={() => props.navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.historyText}>Work Done.. Give Rating!</Text>
      </View>

      <View style={styles.imageContainer}>
        <Image source={require('./asset/Logo/Logo.jpg')} style={styles.newImage} />
        <View style={styles.greenBox}></View>
      </View>
      <View style={styles.imageContainer1}>
        <Image source={require('./asset/Skills/mechanic.png')} style={styles.newImage1} />
        <View style={styles.greenBox}></View>
      </View>
      
      <View style={styles.rectangleContainer}>
        <View style={styles.rectangle26}>
          <View style={styles.infoContainer}>
            <InfoItem iconName="user" placeholder=" Mazdoor Name" />
            <InfoItem iconName="cube" placeholder="Experience" />
            <InfoItem iconName="user-secret" placeholder="Skill" />
            <InfoItem iconName="clock-o" placeholder="Time" />
            <InfoItem iconName="calendar" placeholder="Date" />
            <InfoItem iconName="hourglass" placeholder="Hours" />
          </View>
        </View>
        
        <View style={styles.rectangle27}>
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingText}>Rating</Text>
            <View style={styles.starsContainer}>
              {[1, 2, 3, 4, 5].map((index) => (
                <TouchableOpacity key={index} onPress={() => handleStarPress(index)}>
                  <FontAwesome name={index < rating ? "star" : "star-o"} size={20} color="white" style={{ marginRight: 5 }} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
          <View style={styles.commentContainer}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
              <Text style={styles.commentText}>Comment</Text>
              <TouchableOpacity onPress={toggleTextInput}>
                <FontAwesome name="plus-circle" size={20} color="white" style={{ left: 55, top: 5 }} />
              </TouchableOpacity>
            </View>
            {showTextInput && (
              <TextInput
                placeholder="Type your comment here..."
                onChangeText={(text) => setComment(text)}
                value={comment}
                style={styles.commentInput}
                placeholderTextColor={white}
              />
            )}
          </View>
          
          <TouchableOpacity style={styles.submitButton}onPress={() => props.navigation.navigate("CustomerSearch")}>
            <Text style={styles.submitButtonText}>Submit</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.footer}>
        {/* Footer Content */}
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    backgroundColor: '#00BF63',
    width: '100%',
    paddingTop: 0,
    bottom: -40,
    paddingBottom: 0,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  rectangleContainer: {
    alignItems: 'center',
    marginTop: 40,
  },
  rectangle26: {
    top: -67,
    width: 302,
    height: 290,
    backgroundColor: '#00BF63',
    borderRadius: 28,
    marginBottom: 10,
    alignItems: 'center',
    paddingTop: 20,
  },
  rectangle27: {
    top: -67,
    width: 302,
    height: 245,
    backgroundColor: '#00BF63',
    borderRadius: 28,
    marginBottom: 10,
    alignItems: 'center',
    paddingTop: 20,
  },
  infoContainer: {
    top: 20,
    width: '100%',
    alignItems: 'flex-start',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 20,
  },
  input: {
    flex: 1,
    fontSize: 13,
    height: 28,
    color: white,
    paddingHorizontal: 10,
    backgroundColor: 'transparent',
  },
  footer: {
    backgroundColor: '#00BF63',
    width: '100%',
    paddingTop: 40,
    paddingBottom: 10,
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    paddingHorizontal: 10,
  },
  footerText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    marginTop: 5,
    left: -20,
  },
  historyText: {
    color: 'black',
    bottom: -50,
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    left: -50,
  },
  newImage: {
    width: 93,
    height: 93,
    borderRadius: 250,
    alignSelf: 'center',
    top: 0,
    right: 0,
    position: 'absolute',
    zIndex: 1,
  },
  imageContainer: {
    position: 'relative',
    top: 115,
    left: 70,
    width: 93,
    height: 93,
  },
  newImage1: {
    width: 93,
    height: 93,
    alignSelf: 'center',
    top: 0,
    right: 0,
    position: 'absolute',
    zIndex: 1,
  },
  imageContainer1: {
    position: 'relative',
    top: 200,
    left: 70,
    width: 93,
    height: 93,
  },
  greenBox: {
    width: '100%',
    height: '100%',
    borderRadius: 250,
    backgroundColor: '#00BF63',
    position: 'absolute',
    top: 0,
    right: 0,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  starsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    left: 27,
    top: 1,
  },
  ratingText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '400',
    top: 10,
    left: -25,
  },
  commentText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '400',
    marginRight: 5,
    left:-60,
    top:4,
  },
  commentInput: {
    width: '80%',
    height: 50,
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 10,
    marginTop: 10,
    color: white,
    paddingHorizontal: 10,
  },
  commentContainer: {
    alignItems: 'center',
  },
  submitButton: {
    backgroundColor: '#ffff',
    paddingHorizontal: 20,
    paddingVertical: 5,
    borderRadius: 10,
    borderColor: 'black',
    borderWidth: 1,
    top: 25,
  },
  submitButtonText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
  },

});

export default RatingPageCustomer;
