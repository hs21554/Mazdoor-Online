import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const SplashScreen = (props: { navigation: { replace: (arg0: string) => void; }; }) => {
  useEffect(() => {
    setTimeout(() => {
      props.navigation.replace('GetStarted'); // Replace 'MainScreen' with the name of your main screen component
    }, 1700); // Adjust the duration as needed (3000 milliseconds = 3 seconds)
  }, []);

  return (
    <View style={styles.container}>
      <Image
        source={require('./asset/Logo/Logo.jpg')}
        style={styles.image}
      />
      <Text style={styles.title}>MAZDOOR</Text>
      <Text style={styles.subtitle}>ONLINE</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#00BF63',
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 270,
    height: 300,
    alignItems: 'center',
    resizeMode: 'cover',
  },
  title: {
    color: 'white',
    fontSize: 35,
    bottom: 80,
    fontWeight: 'bold',
    marginTop: 16,
  },
  subtitle: {
    color: 'white',
    bottom: 90,
    fontSize: 33,
    fontWeight: 'bold',
  },
});

export default SplashScreen;
