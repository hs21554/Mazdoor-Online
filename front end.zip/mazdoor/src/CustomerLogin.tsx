import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  Animated,
  Easing,
  Alert,
  ActivityIndicator,
  Modal,
  ScrollView,
} from 'react-native';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import axios from 'axios';
import Background from './Background';
import { useDispatch } from 'react-redux';
import { white } from './Constants';
import Config from './constants/Config';
import { userSignin } from '../store/slices/userSlice';

const LaborLogin = (props: {
  navigation: { navigate: (arg0: string) => void; goBack: () => void };
}) => {
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false); // State for loading animation
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const dispatch = useDispatch();
  const scaleValue = useRef(new Animated.Value(1)).current;

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  const handlePressIn = () => {
    Animated.timing(scaleValue, {
      toValue: 0.9,
      duration: 100,
      easing: Easing.ease,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(scaleValue, {
      toValue: 1,
      duration: 100,
      easing: Easing.ease,
      useNativeDriver: true,
    }).start();
  };

  const handleLogin = async () => {
    if (!email || !password) {
      setErrorMessage('Please enter both email and password');
      setErrorModalVisible(true);
    } else {
      try {
        setIsLoading(true); // Start loading animation
        const { data } = await axios.post(
          `${Config.baseURL}/auth/login`,

          {
            email,
            password,
          }
        );
        if (data?.success) {
          setEmail('');
          setPassword('');
          console.log('dispatched data', data.token);
          dispatch(userSignin({ accessToken: data.token }));
          props.navigation.navigate('CustomerSearch2');
        } else {
          setErrorMessage('Email/Password is not correct!');
          setErrorModalVisible(true);
        }
      } catch (error) {
        console.error('Error logging in:', error);
        setErrorMessage('Email/Password is not correct!');
        setErrorModalVisible(true);
      } finally {
        setIsLoading(false); // Stop loading animation
      }
    }
  };

  return (
    <Background>
      <View style={styles.container}>
        <TouchableOpacity onPress={() => props.navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>WELCOME</Text>
        <Text style={styles.description}>Login back into your account</Text>
        </View>
        <View style={styles.greenBox}>
          <View style={{ alignItems: 'center' }}>
            <Image
              source={require('./asset/Logo/Logo.jpg')}
              style={styles.profileImage}
            />
          </View>
          <Text style={styles.loginText}>LOGIN</Text>
          <View style={styles.inputField}>
            <FontAwesome
              name='envelope'
              size={20}
              color={white}
              style={styles.inputIcon}
            />
            <TextInput
              placeholder='  Email'
              placeholderTextColor={white}
              style={styles.input}
              onChangeText={(text) => setEmail(text)}
              value={email}
              keyboardType='email-address'
            />
          </View>
          <View style={styles.inputField}>
            <FontAwesome
              name='lock'
              size={20}
              color={white}
              style={styles.inputIcon}
            />
            <TextInput
              placeholder='  Password'
              placeholderTextColor={white}
              secureTextEntry={!passwordVisible}
              style={styles.input}
              onChangeText={(text) => setPassword(text)}
              value={password}
            />
            <TouchableOpacity onPress={togglePasswordVisibility}>
              <FontAwesome
                name={passwordVisible ? 'eye-slash' : 'eye'}
                size={20}
                color={white}
                style={styles.passwordIcon}
              />
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={styles.forgotPassword}
            onPress={() => console.log('Forgot password pressed')}
          >
            <Text style={styles.forgotPasswordText}></Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={handleLogin}
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
            disabled={isLoading} // Disable button during loading
          >
            <Animated.View style={{ transform: [{ scale: scaleValue }] }}>
              <View style={styles.signUpButton}>
                {isLoading ? ( // Render loading animation if loading
                  <ActivityIndicator color='black' />
                ) : (
                  <Text style={styles.buttonText}>LOGIN</Text>
                )}
              </View>
            </Animated.View>
          </TouchableOpacity>
          {/* Error Modal */}
          <Modal
            animationType='slide'
            transparent={true}
            visible={errorModalVisible}
            onRequestClose={() => setErrorModalVisible(false)}
          >
            <View style={styles.centeredView}>
              <View style={styles.modalView}>
                <Text style={styles.modalText}>{errorMessage}</Text>
                <TouchableOpacity
                  style={{ ...styles.openButton, backgroundColor: '#00BF63' }}
                  onPress={() => setErrorModalVisible(false)}
                >
                  <Text style={styles.textStyle}>Ok</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </View>

        <View style={styles.orContainer}>
          <View style={styles.line}></View>
          <View style={styles.line}></View>
        </View>

        

        {/* Terms and Conditions */}
        <Text style={styles.termsText}>
          By continuing, you agree to Mazdoor’s Online{'\n'}
          <Text style={styles.linkText}>Terms of Services, Privacy Policy</Text>
        </Text>

        <View style={styles.line1}></View>

        {/* Don't have an account? */}
        <View style={styles.signupContainer}>
          <Text style={styles.signupText}>Don't have an account? </Text>
          <TouchableOpacity
            onPress={() => props.navigation.navigate('CustomerSignup')}
          >
            <Text style={styles.signupLink}>Signup</Text>
          </TouchableOpacity>
        </View>

    </Background>
  );
};

const styles = StyleSheet.create({
  container: {
    top:250,
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  
  line: {
    flex: 1,
    height: 0.5,
    top:40,
    marginBottom: 7,
    backgroundColor: 'grey',
  },
  line1: {
    flex: 1,
    height: 0.5,
    marginBottom: 7,
    backgroundColor: '#D3D3D3', // Light grey color
    marginHorizontal: 80,
    marginVertical: 50,
    top: -60,
  },
  orContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  facebookButton: {
    width: 263,
    height: 31,
    backgroundColor: '#4167B2',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  googleButton: {
    width: 263,
    height: 31,
    backgroundColor: '#FFFFFF',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
  },
  buttonText: {
    color: 'black',
    fontSize: 13,
    fontWeight: 'bold',
  },
  title: {
    marginTop: 50,
    top: -200,
    left: -40,
    color: 'black',
    fontSize: 25,
    fontWeight: 'bold',
  },
  description: {
    color: 'black',
    top: -200,
    left: -40,
    fontSize: 12,
    marginBottom: 70,
    marginHorizontal: 3,
  },
  loginText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    top: -70,
    left: -100,
  },
  greenBox: {
    alignSelf: 'center', // Center horizontally
    width: 340,
    height: 350, // Adjusted height to accommodate the image and input fields
    backgroundColor: '#00BF63',
    borderRadius: 50,
    marginBottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
    top: 35,
  },
  inputField: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 5,
    top: -60,
    paddingHorizontal: 15,
    width: 300,
    height: 35,
  },
  inputIcon: {
    marginRight: 5,
  },
  input: {
    flex: 1,
    color: white,
    height: 25,
  },
  passwordIcon: {
    marginLeft: 10,
  },
  signUpButton: {
    backgroundColor: 'white',
    width: 200,
    paddingVertical: 7,
    marginTop: 5,
    borderRadius: 30,
    alignItems: 'center',
    top: -40,
  },
  socialButtons: {
    flexDirection: 'column',
    alignItems: 'center',
    marginBottom: 30,
  },
  termsText: {
    color: 'black',
    fontSize: 11,
    textAlign: 'center',
    top: 50,
  },
  linkText: {
    color: '#4167B2',
    textDecorationLine: 'underline',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 100,
    top: -5,
    right: -90,
    marginBottom: 20,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginRight: 20,
    marginBottom: 10,
    top: -60,
  },
  forgotPasswordText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  iconTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  socialButtonText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  backButton: {
    position: 'absolute',
    left: -40,
    top: -178,
    zIndex: 1,
  },
  signupContainer: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  signupText: {
    fontSize: 12,
    fontWeight: 'bold',
    top: -30,
  },
  signupLink: {
    color: '#4167B2',
    fontWeight: 'bold',
    fontSize: 12,
    top: -30,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 20,
    paddingHorizontal: 25,
    paddingVertical: 8,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

export default LaborLogin;
