import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import Background from './Background';

interface SearchResultProps {
  route: {
    params?: {
      selectedSkill?: string;
    };
  };
  navigation: {
    navigate: (arg0: string) => void;
  };
}

const SearchResult = ({ route, navigation }: SearchResultProps) => {
  const [selectedSkill, setSelectedSkill] = useState<string | undefined>(route.params?.selectedSkill);

  useEffect(() => {
    if (route.params && route.params.selectedSkill) {
      setSelectedSkill(route.params.selectedSkill);
    }
  }, [route.params]);

  const handleLocationPress = () => {
    console.log("Location icon pressed");
  };

  return (
    <Background>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={handleLocationPress}>
            <MaterialIcons name="location-on" size={24} color="white" style={styles.locationIcon} />
          </TouchableOpacity>
          <Text adjustsFontSizeToFit numberOfLines={1} style={styles.headerText}>Mazdoor Online</Text>
        
        </View>
        <Text adjustsFontSizeToFit numberOfLines={1} style={styles.head}>
          {selectedSkill ? `Results For ${selectedSkill}` : 'Results for'}
        </Text>
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          {[...Array(15).keys()].map((item, index) => (
            <TopRatedWorkers key={index} navigation={navigation} />
          ))}
        </ScrollView>
      </View>
    </Background>
  );
};

interface TopRatedWorkersProps {
  navigation: {
    navigate: (arg0: string) => void;
  };
}

const TopRatedWorkers = ({ navigation }: TopRatedWorkersProps) => 
{
  const name = 'Imtiaz';
  const category = 'Plumber';
  const rating = 4.5;
  const reviews = 120;
  const price = '2000/day';

  const handlePress = () => {
    navigation.navigate('RatingPageCustomer'); // Replace 'ResultPage' with your target page
  };

  return (
    <TouchableOpacity onPress={handlePress} style={styles.card}>
      <Image source={{ uri: 'https://via.placeholder.com/150' }} style={styles.cardImage} />
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{name}</Text>
        <Text style={styles.cardCategory}>{category}</Text>
        <View style={styles.ratingContainer}>
          <MaterialIcons name="star" size={16} color="#FFD700" />
          <Text style={styles.ratingText}>{rating} ({reviews})</Text>
        </View>
        <Text style={styles.cardPrice}>{price}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'stretch',
    justifyContent: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 5,
    backgroundColor: '#00BF63',
    top: 40,
    height: 55,
    width: '100%',
    justifyContent: 'space-between',
  },
  headerText: {
    color: 'white',
    fontSize: 20,
    left: -180,
    fontWeight: 'bold',
  },
  locationIcon: {
    right: -300,
  },
  signupButton: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FFFFFF',
    borderRadius: 0,
    paddingVertical: 6,
    paddingHorizontal: 16,
    height: 38,
    left: -20,
  },
  signupText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
    textAlign: 'center',
  },
  head: {
    width: '70%',
    color: '#000000',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 80,
    marginHorizontal: 20,
    textAlign: 'center',
  },
  scrollContainer: {
    paddingHorizontal: 15,
    paddingTop: 10,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 2,
    marginVertical: 10,
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
  },
  cardImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  cardContent: {
    flex: 1,
    paddingLeft: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  cardCategory: {
    fontSize: 14,
    color: '#777',
    marginVertical: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },
  ratingText: {
    fontSize: 14,
    color: '#777',
    marginLeft: 4,
  },
  cardPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#00BF63',
  },
});

export default SearchResult;
