import React, { useState } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TextInput, TouchableOpacity, Dimensions, Modal, GestureResponderEvent } from 'react-native';
import Background from './Background';
import { MaterialIcons } from '@expo/vector-icons';

const CustomerSearch = (props: { navigation: { navigate: any; }; }) => {
  const { width, height } = Dimensions.get('window');
  const [selectedSkill, setSelectedSkill] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [locationDropdownVisible, setLocationDropdownVisible] = useState(false);
  const [skillDropdownVisible, setSkillDropdownVisible] = useState(false);
  const [dropdownItems] = useState(["Plumber", "Digger", "Mason", "Painter", "Electrician","Carpenter","Glazier","Mechanic","Labourer","Welder"]);
  const locations = ['Officers Colony', 'Basti', 'Taxila', 'Bahria Phase 1-5', 'Bahria Phase 5-7', 'Ammar Chok', 'Chaklala', 'I-8','G-9'];

  const handleSkillSelect = (skill: React.SetStateAction<string>) => {
    setSelectedSkill(skill);
    setSkillDropdownVisible(false);
    props.navigation.navigate("CustomerLogin", { selectedSkill: skill });
  };

  const handleLocationSelect = (location: React.SetStateAction<string>) => {
    setSelectedLocation(location);
    toggleLocationDropdown();
  };

  const toggleLocationDropdown = () => {
    setLocationDropdownVisible(!locationDropdownVisible);
    setSkillDropdownVisible(false); // Hide skill dropdown when location dropdown is toggled
  };

  const toggleSkillDropdown = () => {
    setSkillDropdownVisible(!skillDropdownVisible);
    setLocationDropdownVisible(false); // Hide location dropdown when skill dropdown is toggled
  };

  const handleLocationPress = () => {
    toggleLocationDropdown();
  };

  const handleChooseSkillPress = () => {
    toggleSkillDropdown();
  };

  function handleSignInPress(event: GestureResponderEvent): void {
    props.navigation.navigate("CustomerLogin", { selectedSkill });
  }

  return (
    <Background>
      <View style={[styles.container, (locationDropdownVisible || skillDropdownVisible) && styles.modalContainer]}>
        <View style={styles.header}>
          <TouchableOpacity onPress={handleLocationPress}>
            <MaterialIcons name="location-on" size={24} color="white" style={styles.locationIcon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLocationPress}>
            <View style={styles.locationTextBoxContainer}>
              <TextInput
                style={styles.locationTextBox}
                placeholder="Location"
                value={selectedLocation}
                onChangeText={(text) => setSelectedLocation(text)}
                editable={false}
              />
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleSignInPress}>
            <Text style={styles.signInButton}>Sign In</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.search}>
          <Text adjustsFontSizeToFit numberOfLines={1} style={styles.searchHeaderText}>What Service Are You Looking For!</Text>
          <TouchableOpacity onPress={handleChooseSkillPress} style={styles.skillSelection}>
            <Text numberOfLines={1} style={styles.heading}>
              {selectedSkill ? selectedSkill : 'Choose a skill'}
            </Text>
          </TouchableOpacity>
        </View>
        <Text adjustsFontSizeToFit numberOfLines={1} style={styles.head}>
          Top Rated Workers
        </Text>
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          {[...Array(1).keys()].map((item, index) => (
            <TopRatedWorkers key={index} navigation={props.navigation} />
          ))}
        </ScrollView>
      </View>
      <Modal
        animationType="slide"
        transparent={true}
        visible={locationDropdownVisible}
        onRequestClose={() => {
          toggleLocationDropdown();
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalView}>
            <ScrollView>
              {locations.map((location, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.dropdownItem}
                  onPress={() => handleLocationSelect(location)}
                >
                  <Text style={styles.dropdownItemText}>{location}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
      <Modal
        animationType="slide"
        transparent={true}
        visible={skillDropdownVisible}
        onRequestClose={() => {
          toggleSkillDropdown();
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalView}>
            <ScrollView>
              {dropdownItems.map((skill, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.dropdownItem}
                  onPress={() => handleSkillSelect(skill)}
                >
                  <Text style={styles.dropdownItemText}>{skill}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </Background>
  );
};


const TopRatedWorkers = (props: { navigation: { navigate: (arg0: string, arg1?: any) => void; }; }) => {
  // Sample data for demonstration
  const workers = [
    { name: 'Ali ', category: 'Plumber', price: '1500/day', rating: '4.9', image: require('./asset/SearchPic/plumber.jpg') },
    { name: 'Mughal G', category: 'Electrician', price: '1200/day', rating: '4.8', image: require('./asset/SearchPic/Electrician.jpg') },
    { name: 'Qasim', category: 'Carpenter', price: '1100/day', rating: '4.7', image: require('./asset/SearchPic/carpenters.jpg') },
    { name: 'Zafar Ali', category: 'Glazier', price: '1200/day', rating: '4.9', image: require('./asset/SearchPic/Glazier.jpg') },
    { name: 'Huzaifa', category: 'Plumber', price: '1000/day', rating: '4.9', image: require('./asset/SearchPic/plumber.jpg') },
    { name: 'Nouman', category: 'Digger', price: '800/day', rating: '4.8', image: require('./asset/SearchPic/Digger.jpg') },
    { name: 'Umer', category: 'Welder', price: '1000/day', rating: '4.6', image: require('./asset/SearchPic/welder.jpg') },
    { name: 'Usman', category: 'Painter', price: '600/day', rating: '4.8', image: require('./asset/SearchPic/painter.jpg') },
  ];

  return (
    <>
      {workers.map((worker, index) => (
        <TouchableOpacity 
          key={index} 
          style={styles.workerCard}
          onPress={() => props.navigation.navigate
            ('CustomerLogin', { worker })}
            >
              <Image source={worker.image} style={styles.workerImage} />
              <View style={styles.workerDetails}>
                <Text style={styles.workerName}>{worker.name}</Text>
                <Text style={styles.workerCategory}>{
worker.category}</Text>
<Text style={styles.workerPrice}>{worker.price}</Text>
<View style={styles.workerRating}>
  <Text style={styles.ratingText}>{worker.rating}</Text>
  <Image source={require('./asset/SearchPic/star.png')} style={styles.starIcon} />
</View>
</View>
</TouchableOpacity>
))}
</>
);
};

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: '#F0F0F0',
paddingHorizontal: 15,
},
dimBackground: {
opacity: 0.5,
},
header: {
flexDirection: 'row',
alignItems: 'center',
backgroundColor: '#00BF63',
top: 26,
borderRadius: 10,
paddingVertical: 10,
paddingHorizontal: 15,
justifyContent: 'space-between',
marginTop: 10,
},
headerText: {
color: 'white',
fontSize: 20,
fontWeight: 'bold',
},
locationIcon: {
marginRight: 15,
top:-2,
},
signInButton: {
color: 'white',
fontSize: 18,
fontWeight: 'bold',
marginRight: 10,
top:-3,
},
locationTextBoxContainer: {
flex: 1,

},
locationTextBox: {
backgroundColor: 'white',
borderRadius: 5,
left:-38,
paddingHorizontal:10,
width:160,
},
search: {
backgroundColor: '#00BF63',
padding: 20,
top: 30,
borderRadius: 10,
marginBottom: 20,
},
searchHeaderText: {
color: 'white',
fontSize: 18,
fontWeight: 'bold',
marginBottom: 10,
},
skillSelection: {
marginTop: 10,
backgroundColor: 'white',
padding: 10,
borderRadius: 5,
alignItems: 'center',
},
heading: {
color: 'black',
fontSize: 16,
fontWeight: 'bold',
},
head: {
color: 'black',
top: 5,
fontSize: 20,

fontWeight: 'bold',
marginVertical: 20,
textAlign: 'center',
},
scrollContainer: {
paddingBottom: 20,
},
modalOverlay: {
flex: 1,
backgroundColor: 'rgba(0, 0, 0, 0.5)',
justifyContent: 'center',
alignItems: 'center',
},
modalView: {
backgroundColor: "white",
borderRadius: 10,
padding: 20,
alignItems: "center",
shadowColor: "#000",
shadowOffset: {
width: 0,
height: 2
},
shadowOpacity: 0.25,
shadowRadius: 3.84,
elevation: 5,
width: '80%',
maxHeight: '70%',
},
dropdownItem: {
paddingVertical: 10,
paddingHorizontal: 5,
borderBottomWidth: 1,
borderBottomColor: '#ccc',
},
selectedItem: {
backgroundColor: '#00BF63',
},
dropdownItemText: {
fontSize: 16,
color: '#000',
},
workerCard: {
backgroundColor: '#fff',
borderRadius: 10,
overflow: 'hidden',
marginBottom: 20,
flexDirection: 'row',
alignItems: 'center',
padding: 10,
shadowColor: '#000',
shadowOffset: { width: 0, height: 2 },
shadowOpacity: 0.2,
shadowRadius: 2,
elevation: 3,
},
workerImage: {
width: 80,
height: 80,
borderRadius: 40,
},
workerDetails: {
marginLeft: 10,
flex: 1,
},
workerName: {
fontSize: 16,
fontWeight: 'bold',
marginBottom: 5,
},
workerCategory: {
fontSize: 14,
color: '#666',
marginBottom: 5,
},
workerPrice: {
fontSize: 14,
fontWeight: 'bold',
color: '#00BF63',
marginBottom: 5,
},
workerRating: {
flexDirection: 'row',
alignItems: 'center',
},
ratingText: {
fontSize: 14,
fontWeight: 'bold',
marginRight: 5,
},
starIcon: {
width: 15,
height: 15,
},
modalContainer: {
backgroundColor: 'rgba(0, 0, 0, 0.0)', // Semi-transparent black background
},
});

export default CustomerSearch;
