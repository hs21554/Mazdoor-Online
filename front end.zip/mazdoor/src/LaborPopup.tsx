import React, { useState } from 'react';
import { View, StyleSheet, TextInput, Image, TouchableOpacity, Modal } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import LaborProfile from './LaborProfile'; // Import LaborProfile component
import { white } from './Constants';

const InfoItem = (props: { iconName: string; placeholder: string }) => {
  const { iconName, placeholder } = props;
  let iconComponent;

  switch (iconName) {
    case "user":
      iconComponent = <FontAwesome name="user" size={20} color={white} style={styles.icon} />;
      break;
    case "map-marker":
      iconComponent = <FontAwesome name="map-marker" size={20} color={white} style={styles.icon} />;
      break;
    case "clock-o":
      iconComponent = <FontAwesome name="clock-o" size={20} color={white} style={styles.icon} />;
      break;
    case "calendar":
      iconComponent = <FontAwesome name="calendar" size={20} color={white} style={styles.icon} />;
      break;
    case "hourglass":
      iconComponent = <FontAwesome name="hourglass" size={20} color={white} style={styles.icon} />;
      break;
    default:
      iconComponent = null;
  }

  return (
    <View style={styles.infoItem}>
      {iconComponent}
      <TextInput editable={false} placeholder={placeholder} placeholderTextColor={white} style={styles.input} />
    </View>
  );
};

const LaborPopup = () => {
  const [isPopupVisible, setIsPopupVisible] = useState(true); // State to manage popup visibility

  const handleCrossButtonPress = () => {
    setIsPopupVisible(false); // Close the popup
  };

  return (
    <View style={styles.container}>
      {/* LaborProfile screen */}
      <LaborProfile navigation={{ navigate: () => {}, goBack: () => {} }} />

      {/* Popup Content */}
      <Modal
        visible={isPopupVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setIsPopupVisible(false)}
      >
        <View style={styles.popupContainer}>
          <View style={styles.rectangle26}>
            <Image source={require('./asset/Logo/Logo.jpg')} style={styles.rectangleImage} />
            <TouchableOpacity onPress={handleCrossButtonPress} style={styles.crossButton}>
              <FontAwesome name="times-circle" size={24} color={white} />
            </TouchableOpacity>
            <View style={styles.infoContainer}>
              {/* Info Items */}
              <InfoItem iconName="user" placeholder="  Customer Name" />
              <InfoItem iconName="map-marker" placeholder="   Address" />
              <InfoItem iconName="clock-o" placeholder="  Time" />
              <InfoItem iconName="calendar" placeholder="  Date" />
              <InfoItem iconName="hourglass" placeholder="   Hours" />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  popupContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background
  },
  rectangle26: {
    width: 302,
    height: 300,
    backgroundColor: '#00BF63',
    borderRadius: 28,
    alignItems: 'center',
    paddingTop: 20,
  },
  infoContainer: {
    width: '100%',
    left:30,
    alignItems: 'flex-start',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 13,
    height: 28,
    color: white,
    backgroundColor: 'transparent',
  },
  rectangleImage: {
    width: 92,
    height: 92,
  },
  crossButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    marginRight: 10,
    marginTop: 10,
  },
});

export default LaborPopup;
