import React, { ReactNode } from 'react'; // Import React and ReactNode
import { View, ImageBackground } from 'react-native';

interface BackgroundProps {
  children: ReactNode; // Use ReactNode type for children
}

const Background = ({ children }: BackgroundProps) => {
  return (
    <View style={{ flex: 1 }}>
      <ImageBackground source={require("./asset/BackGround/whiteback.jpg")} style={{ height: '100%', width: '100%' }}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          {children}
        </View>
      </ImageBackground>
    </View>
  );
}

export default Background;