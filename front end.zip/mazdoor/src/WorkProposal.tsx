import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Image,
  Modal,
} from 'react-native';
import { FontAwesome, MaterialIcons, Ionicons } from '@expo/vector-icons';
import axios from 'axios';
import DropdownMenu from './dropdownmenu';
import Config from './constants/Config';

export default function App(props: any) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState('Experience');
  const [price, setPrice] = useState('');
  const [experience, setExperience] = useState('');
  const [isPriceFieldFocused, setIsPriceFieldFocused] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handlePriceChange = (text: string) => {
    if (text.length <= 7) {
      setPrice(text);
      setIsPriceFieldFocused(true);
    } else {
      Alert.alert('Error', 'Price cannot exceed 7 digits.');
    }
  };

  const handleExperienceChange = (text: string) => {
    const numericValue = parseInt(text);
    if (text === '' || (numericValue >= 1 && numericValue <= 20)) {
      setExperience(text);
    } else {
      Alert.alert('Error', 'Please enter a value between 1 and 20.');
    }
  };

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option);
    setExperience(option);
    setIsDropdownOpen(false);
  };

  const handleSubmit = async () => {
    if (price === '' || experience === '') {
      setErrorMessage('Please fill all fields!');
      setErrorModalVisible(true);
    } else {
      try {
        const { data } = await axios.post(`${Config.baseURL}/auth/laborStats`, {
          price,
          experience,
        });

        if (data?.success) {
          setPrice('');
          setExperience('');
          // Navigating to LaborProfile screen
        } else {
          props.navigation.navigate('LaborProfile');
        }
      } catch (error) {
        console.error('Error:', error);
        Alert.alert('Error', 'Something went wrong. Please try again later.');
      }
    }
  };

  const handleBack = () => {
    // Implement navigation back
  };

  return (
    <View style={{ backgroundColor: '#fff', flex: 1 }}>
      <View style={styles.header}>
        {/* dropdown list */}
        <DropdownMenu navigation={props.navigation} />
        <TouchableOpacity
          onPress={() => props.navigation.goBack()}
          style={styles.backButton}
        >
          <Ionicons name='arrow-back' size={24} color='white' />
        </TouchableOpacity>
        <Text style={styles.heading}>Work Proposal</Text>
      </View>

     
      


      <View style={styles.rectangle26}>
        <View style={styles.rectangleGreen}>
          <View style={styles.fieldContainer}>
            <TextInput
              style={[
                styles.input,
                styles.experienceText,
                !isPriceFieldFocused && experience === '' && { opacity: 100 },
              ]}
              keyboardType='numeric'
              value={price}
              placeholder='Price > 100  '
              placeholderTextColor='white'
              onFocus={() => setIsPriceFieldFocused(true)}
              onBlur={() => setIsPriceFieldFocused(false)}
              onChangeText={handlePriceChange}
            />
            <Image
              style={{ width: 23, height: 23, marginLeft: 10 }}
              source={require('./asset/WorkProposal/money.png')}
            />
          </View>
          <View style={styles.fieldContainer}>
            <TextInput
              style={[
                styles.input,
                styles.experienceText,
                !isPriceFieldFocused && experience === '' && { opacity: 100 },
              ]}
              keyboardType='numeric'
              value={experience}
              placeholder='Experience'
              placeholderTextColor='white'
              onBlur={() => setIsDropdownOpen(false)}
              onChangeText={handleExperienceChange}
            />
            <TouchableOpacity onPress={toggleDropdown}>
              <View style={styles.dropdownContainer}>
                <FontAwesome name='chevron-down' size={20} color='white' />
              </View>
            </TouchableOpacity>
          </View>
          <View
            style={[
              styles.submitButtonContainer,
              isDropdownOpen && styles.submitButtonContainerOpen,
            ]}
          >
            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmit}
            >
              <Text style={styles.submitText}>SUBMIT</Text>
            </TouchableOpacity>
            <Modal
              animationType='slide'
              transparent={true}
              visible={errorModalVisible}
              onRequestClose={() => setErrorModalVisible(false)}
            >
              <View style={styles.centeredView}>
                <View style={styles.modalView}>
                  <Text style={styles.modalText}>{errorMessage}</Text>
                  <TouchableOpacity
                    style={{ ...styles.openButton, backgroundColor: '#00BF63' }}
                    onPress={() => setErrorModalVisible(false)}
                  >
                    <Text style={styles.textStyle}>Ok</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </Modal>
          </View>
        </View>
        {isDropdownOpen && (
          <View style={[styles.dropdown, { top: 132, zIndex: 1 }]}>
            <ScrollView
              style={[styles.scrollview, { marginTop: 10 }]}
              contentContainerStyle={styles.scrollContent}
            >
              {['None', ...Array.from(Array(20), (e, i) => `${i + 1}`)].map(
                (option, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.dropdownItem,
                      selectedOption === option && styles.selectedItem,
                    ]}
                    onPress={() => handleOptionSelect(option)}
                  >
                    <Text style={styles.dropdownItemText}>{option}</Text>
                  </TouchableOpacity>
                )
              )}
            </ScrollView>
          </View>
        )}
      </View>
      <Image
        style={styles.additionalImage}
        source={require('./asset/WorkProposal/team.jpg')}
      />
      <View style={styles.footer}>{/* Green footer content */}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 20,
    paddingHorizontal: 25,
    paddingVertical: 8,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 50,
    marginHorizontal: 0,
    paddingTop: 10,
    backgroundColor: '#00BF63',
    paddingVertical: 10,
    paddingHorizontal: 45,
  },
  menuTouchable: {
    padding: 10,
  },
  menuIcon: {},
  plumbersContainer: {
    alignItems: 'center',
    marginTop: 20,
    flexDirection: 'column',
    justifyContent: 'center',
  },
  plumberImage: {
    marginTop: 6,
    width: 90,
    height: 83,
  },
  plumberInfo: {
    marginTop: 10,
    alignItems: 'center',
  },
  plumberTitle: {
    marginTop: 5,
    color: 'black',
    fontSize: 20,
    fontWeight: 'bold',
  },
  rectangle26: {
    alignItems: 'center',
    marginTop: 20,
    top:50,
  },
  rectangleGreen: {
    width: 332,
    height: 250,
    borderRadius: 28,
    backgroundColor: '#00BF63',
    justifyContent: 'space-between',
    paddingTop: 70,
    paddingHorizontal: 10,
    position: 'relative',
  },
  fieldContainer: {
    width: '90%',
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 5,
    paddingVertical: 5,
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  experienceText: {
    color: 'white',
    fontSize: 12,
    flex: 1,
  },
  dropdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  submitButtonContainer: {
    width: '100%',
    alignItems: 'center',
    marginTop: 10,
  },
  submitButtonContainerOpen: {
    justifyContent: 'flex-start',
    marginLeft: -50,
  },
  heading: {
    color: 'white',
    fontSize: 22,
    left: -50,
    fontWeight: 'bold',
  },
  submitButton: {
    marginBottom: 100,
    width: 122,
    height: 39,
    backgroundColor: 'white',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  submitText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  dropdown: {
    position: 'absolute',
    right: 55,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 5,
    paddingHorizontal: 20,
  },
  scrollview: {
    maxHeight: 200,
  },
  scrollContent: {
    paddingRight: 20,
  },
  dropdownItem: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'black',
    alignItems: 'center',
  },
  selectedItem: {
    backgroundColor: '#00BF63',
  },
  dropdownItemText: {
    color: 'black',
    fontSize: 12,
  },
  input: {
    fontSize: 12,
    color: 'white',
  },
  workProposalText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 21,
    right: -20,
    fontWeight: 'bold',
    flex: 1,
  },
  additionalImage: {
    width: 380,
    marginLeft: -15,
    height: 250,
    alignSelf: 'center',
    marginTop: 35,
    top:80,
    position: 'relative',
    zIndex: 0,
  },
  footer: {
    backgroundColor: '#00BF63',
    paddingHorizontal: 16,
    paddingVertical: 25,
    marginTop: 20,
    top:120
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuContainer: {
    width: 150,
    top: -305,
    left: 120,
    backgroundColor: 'white',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 10,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  menuItemText: {
    marginLeft: 10,
    fontSize: 16,
  },
  backButton: {
    position: 'absolute',
    left: 25,
    top: 17,
    zIndex: 1,
  },
});
