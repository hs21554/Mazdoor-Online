import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  ScrollView,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';
import DropdownMenu2 from './dropdownmenuProfile';
import Config from './constants/Config';
import axios from 'axios';
import { useSelector } from 'react-redux';
import { selectUser } from '../store/selectors/userSelect';

interface Props {
  navigation: {
    navigate: (arg0: string) => void;
    goBack: () => void;
  };
}

const CustomerProfile: React.FC<Props> = ({ navigation }) => {
  const handleBackPress = () => {
    console.log('Back button pressed');
    navigation.goBack();
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior='padding' enabled>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBackPress} style={styles.backButton}>
          <Ionicons name='arrow-back' size={24} color='white' />
        </TouchableOpacity>
        <DropdownMenu2 navigation={navigation} />
        <Image
          source={require('./asset/Logo/Logo.jpg')}
          style={styles.headerImage}
        />
        <View style={{ flex: 1 }}></View>
      </View>
      <LargeBox />
      <Rectangle12 navigation={navigation} />
      <Footer navigation={navigation} />
    </KeyboardAvoidingView>
  );
};

const LargeBox = () => {
  return <View style={styles.largeBox} />;
};

const Rectangle12: React.FC<Props> = ({ navigation }) => {
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [location, setLocation] = useState('');
  const [cnic, setCnic] = useState('');
  const [image, setImage] = useState('');
  const [blink, setBlink] = useState(true);
  const [gigs, setGigs] = useState([]);
  const user = useSelector(selectUser);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlink((b) => !b);
    }, 500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${Config.baseURL}/auth/getUser`, {
          headers: {
            Authorization: `Bearer ${user.accessToken}`,
          },
        });
        console.log('Fetched data:', response.data);

        const data = response?.data?.user;

        setName(data.name);
        setPhoneNumber(data.phoneNumber);
        setLocation(data.city);
       
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [user.accessToken]);


  const getRandomGigs = (gigsArray: any[]) => {
    if (gigsArray.length <= 2) return gigsArray;
    const shuffled = gigsArray.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, 2);
  };

  return (
    <View style={styles.fieldsContainer}>
      <View style={styles.newImageContainer}>
        {image ? (
          <Image source={{ uri: image }} style={styles.newImage} />
        ) : (
          <Image
            source={require('./asset/MainPage/labor.jpg')}
            style={styles.newImage}
          />
        )}
      </View>
      <TouchableOpacity
        style={styles.editTextContainer}
        onPress={() => navigation.navigate('CustomerProfile')}
      >
        
      </TouchableOpacity>
      <View style={styles.rectangle}>
        <FontAwesome name='user' style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder='Name'
            placeholderTextColor='white'
            value={name}
            onChangeText={(text) => setName(text)}
          />
        </View>
      </View>
      <View style={styles.rectangle}>
        <FontAwesome name='phone' style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder='Phone Number'
            placeholderTextColor='white'
            keyboardType='numeric'
            value={phoneNumber}
            onChangeText={(text) => setPhoneNumber(text)}
          />
        </View>
      </View>
      <View style={styles.rectangle}>
        <FontAwesome name='map-marker' style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder='Location'
            placeholderTextColor='white'
            value={location}
            onChangeText={(text) => setLocation(text)}
          />
        </View>
      </View>
   
      <View style={styles.rectangle}>
        <FontAwesome name='briefcase' style={styles.icon} />
        <View style={[styles.input, styles.jobsInput]}>
          
            <Text style={[styles.text]}>
              My Booking
            </Text>
         
        </View>
      </View>
     
      <TouchableOpacity onPress={() => console.log('Remove pressed')}>
        <Text style={[styles.text, styles.addText1]}>Remove</Text>
      </TouchableOpacity>
    </View>
  );
};



const Footer: React.FC<Props> = ({ navigation }) => {
  return (
    <View style={styles.footer}>
      <TouchableOpacity
        style={styles.footerItem}
        onPress={() => navigation.navigate('LaborOffers')}
      >
        <AntDesign name='user' size={24} color='white' />
        <Text style={styles.footerItemText}>Request</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.footerItem}
        onPress={() => navigation.navigate('LaborHistory')}
      >
        <FontAwesome name='briefcase' size={24} color='white' />
        <Text style={styles.footerItemText}>My Work</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.footerItem}
        onPress={() => navigation.navigate('Chat')}
      >
        
        <Text style={styles.footerItemText}></Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  gigsScrollView: {
    flex: 1,
  },
  gigsContainer: {
    padding: 10,
  },
  gigTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  gigDetail: {
    fontSize: 14,
    color: '#666',
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  gigContainer: {
    backgroundColor: '#e0e0e0',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  gigText: {
    color: '#333',
    fontSize: 14,
  },

  fieldsContainer: {
    position: 'absolute',
    bottom: 100,
    alignSelf: 'center',
    width: 302,
    paddingHorizontal: 10,
  },
  imageContainer: {
    width: 100,
    height: 100,
    top: -60,
    right: -180,
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 250,
  },
  newImageContainer: {
    width: 130,
    height: 130,
    marginBottom: 40,
  },
  newImage: {
    width: '100%',
    height: '100%',
    borderRadius: 250,
    top:-60,
    left:75,
  },
  headerImage: {
    width: 70,
    height: 40,
    top: -5,
    marginTop: 10,
    right: -115,
  },
  header: {
    backgroundColor: '#00BF63',
    width: '100%',
    paddingTop: 8,
    top: -350,
    paddingBottom: 10,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 0,
  },
  rectangle: {
    backgroundColor: '#00BF63',
    width: '100%',
    height: 31,
    top: -75,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    borderWidth: 1,
    borderColor: 'white',
  },
  icon: {
    color: 'white',
    fontSize: 20,
    marginHorizontal: 10,
  },
  text: {
    color: 'white',
    fontSize: 11,
    fontWeight: '400',
  },
  input: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  jobsInput: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  addText: {
    marginLeft: 100,
  },
  largeBox: {
    position: 'absolute',
    bottom: 100,
    alignSelf: 'center',
    width: 340,
    height: 466,
    backgroundColor: '#00BF63',
    borderRadius: 28,
    borderWidth: 1,
    borderColor: 'white',
    zIndex: -1,
  },
  editTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    top: 260,
    left: 285,
    transform: [{ translateX: -50 }],
    zIndex: 1,
  },
  editIcon: {
    color: 'white',
    fontSize: 18,
    marginRight: 5,
    bottom: 140,
  },
  editText: {
    color: 'white',
    bottom: 140,
    fontSize: 15,
    fontWeight: '400',
    left: -2,
  },
  textInput: {
    color: 'white',
    fontSize: 11,
    fontWeight: '400',
  },
  backButton: {
    marginTop: 30,
    marginLeft: 0,
    bottom: 13,
    left: 22,
  },
  dropdownIcon: {
    marginLeft: 10,
  },
  dropdownContent: {
    backgroundColor: 'white',
    position: 'absolute',
    top: 467,
    left: 157,
    padding: 15,
    borderRadius: 5,
    zIndex: 1,
  },
  scrollView: {
    maxHeight: 150,
    paddingRight: 20,
  },
  dropdownItem: {
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    paddingVertical: 5,
    fontSize: 14,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: '#00BF63',
    paddingVertical: 10,
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingHorizontal: 20,
  },
  footerItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  footerItemText: {
    color: 'white',
    fontSize: 11,
    marginLeft: 5,
  },
  addText1: {
    color: 'white',
    top: -70,
    right: -2,
  },
  blinkingText: {
    opacity: 0.5,
  },
});

export default CustomerProfile;