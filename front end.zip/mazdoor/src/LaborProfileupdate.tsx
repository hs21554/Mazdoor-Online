import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, TextInput, KeyboardAvoidingView, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { AntDesign } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons
import DropdownMenu2 from './dropdownmenuProfile';

interface Props {
  navigation: {
    navigate: (arg0: string) => void;
    goBack: () => void; // Added goBack function
  };
}

const LaborProfileupdate: React.FC<Props> = ({ navigation }) => {
  const handleBackPress = () => {
    console.log('Back button pressed');
    navigation.goBack();
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior="padding" enabled>
      {/* Header */}
      <View style={styles.header}>
        {/* Back button */}
        <TouchableOpacity onPress={handleBackPress} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>

        {/* Centered header image */}
        {/* dropdown list */}
        <DropdownMenu2 navigation={navigation} />
        <Image source={require('./asset/Logo/Logo.jpg')} style={styles.headerImage} />

        {/* Placeholder for center alignment */}
        <View style={{ flex: 1 }}></View>
      </View>

      {/* Large box */}
      <LargeBox />

      {/* Rectangle 12 */}
      <Rectangle12 navigation={navigation} />

      {/* Footer */}
      <Footer navigation={navigation} />
    </KeyboardAvoidingView>
  );
};

const LargeBox = () => {
  return <View style={styles.largeBox} />;
};

const Rectangle12: React.FC<Props> = ({ navigation }) => {
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [location, setLocation] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // State to manage dropdown visibility

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <View style={styles.fieldsContainer}>
      <View style={styles.newImageContainer}>
        <Image source={require('./asset/MainPage/labor.jpg')} style={styles.newImage} />
      </View>
      {/* Adding the "Edit" text */}
      <TouchableOpacity style={styles.editTextContainer} onPress={() => navigation.navigate("LaborProfile")}>
       
        <Text style={styles.editText}>Update</Text>
      </TouchableOpacity>
      {/* End of "Edit" text */}
      <View style={styles.rectangle}>
        <FontAwesome name="user" style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder="Name"
            placeholderTextColor="white" // Set placeholder text color to white
            value={name}
            onChangeText={text => setName(text)}
          />
        </View>
      </View>
      <View style={styles.rectangle}>
        <FontAwesome name="phone" style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder="Phone Number"
            placeholderTextColor="white" // Set placeholder text color to white
            keyboardType="numeric"
            value={phoneNumber}
            onChangeText={text => setPhoneNumber(text)}
          />
        </View>
      </View>
      <View style={styles.rectangle}>
        <FontAwesome name="map-marker" style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder="Location"
            placeholderTextColor="white" // Set placeholder text color to white
            value={location}
            onChangeText={text => setLocation(text)}
          />
        </View>
        
      </View>
      <View style={styles.rectangle}>
        <FontAwesome name="address-card" style={styles.icon} />
        <View style={styles.input}>
          <TextInput
            style={styles.textInput}
            placeholder="CNIC"
            placeholderTextColor="white" // Set placeholder text color to white
            value={location}
            onChangeText={text => setLocation(text)}
          />
        </View>
        
      </View>
      <View style={styles.rectangle}>
        <FontAwesome name="briefcase" style={styles.icon} />
        <View style={[styles.input, styles.jobsInput]}>
          <Text style={styles.text}>Jobs</Text>
        </View>
      </View>
      {/* New field with increased height */}
      <View style={[styles.rectangle, { height: 120, marginTop: -15 }]}></View>

      <TouchableOpacity onPress={() => console.log("Remove pressed")}>
        <Text style={[styles.text, styles.addText1]}>Remove</Text>
      </TouchableOpacity>
    </View>
  );
};

const Footer: React.FC<Props> = ({ navigation }) => {
  return (
    <View style={styles.footer}>
      <TouchableOpacity style={styles.footerItem} onPress={() => navigation.navigate("LaborOffers")} >
        <AntDesign name="user" size={24} color="white" />
        <Text style={styles.footerItemText}>Request</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.footerItem} onPress={() => navigation.navigate("LaborHistory")}>
        <FontAwesome name="briefcase" size={24} color="white" />
        <Text style={styles.footerItemText}>My Work</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.footerItem} onPress={() => navigation.navigate("Chat")}>
        <FontAwesome name="comment" size={24} color="white" />
        <Text style={styles.footerItemText}>Chat</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fieldsContainer: {
    position: 'absolute',
    bottom: 100,
    alignSelf: 'center',
    width: 302,
    paddingHorizontal: 10,
  },
  imageContainer: {
    width: 100,
    height: 100,
    top: -60,
    right: -180,
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 250,
  },
  newImageContainer: {
    width: 172,
    height: 170,
    marginBottom: 40,
  },
  newImage: {
    width: '100%',
    height: '100%',
  },
  headerImage: {
    width: 70,
    height: 40,
    top: -5,
    marginTop: 10,
    right: -115,
  },
  header: {
    backgroundColor: '#00BF63',
    width: '100%', // Changed to full width
    paddingTop: 8,
    top: -350,
    paddingBottom: 10,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 0, // Added paddingHorizontal
  },
  rectangle: {
    backgroundColor: '#00BF63',
    width: '100%',
    height: 31,
    top: -15,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    borderWidth: 1,
    borderColor: 'white',
  },
  icon: {
    color: 'white',
    fontSize: 20,
    marginHorizontal: 10,
  },
  text: {
    color: 'white',
    fontSize: 11,
    fontWeight: '400',
  },
  input: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  jobsInput: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  addText: {
    marginLeft: 100,
  },
  largeBox: {
    position: 'absolute',
    bottom: 80,
    alignSelf: 'center',
    width: 340,
    height: 466,
    backgroundColor: '#00BF63',
    borderRadius: 28,
    borderWidth: 1,
    borderColor: 'white',
    zIndex: -1,
  },
  editTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center the content horizontally
    position: 'absolute',
    top: 260, // Adjust the top position to move it inside the green box
    left: 285, // Align it to the center horizontally
    transform: [{ translateX: -50 }], // Center horizontally
    zIndex: 1, // Ensure it's above other elements
  },
  editIcon: {
    color: 'white',
    fontSize: 18,
    marginRight: 5,
    bottom: 100,
  },
  editText: {
    color: 'white',
    bottom: 100,
    fontSize: 15,
    fontWeight: '400',
    left: -2,
  },
  textInput: {
    color: 'white',
    fontSize: 11,
    fontWeight: '400',
  },
  backButton: {
    marginTop: 30,
    marginLeft: 0,
    bottom:13,
    left:22,
   
  },
  dropdownIcon: {
    marginLeft: 10,
  },
  dropdownContent: {
    backgroundColor: 'white',
    position: 'absolute',
    top: 467,
    left: 157,
    padding: 15,
    borderRadius: 5,
    zIndex: 1,
  },
  scrollView: {
    maxHeight: 150,
    paddingRight: 20,
  },
  dropdownItem: {
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
    paddingVertical: 5,
    fontSize: 14,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: '#00BF63',
    paddingVertical: 10,
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingHorizontal: 20,
  },
  footerItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  footerItemText: {
    color: 'white',
    fontSize: 11,
    marginLeft: 5,
  },
  addText1: {
    color: 'white', // Set the text color to white
    top: -20,
    right: -2,
  },
});

export default LaborProfileupdate;
