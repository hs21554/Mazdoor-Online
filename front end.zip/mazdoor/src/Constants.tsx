export const green = '#2BB789';
export const black = '#000000';
export const white = '#fff';