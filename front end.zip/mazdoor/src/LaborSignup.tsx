import React, { useRef, useState } from 'react';
import { View, Text, TouchableOpacity, Animated, Easing, Image, TextInput, Modal, StyleSheet, ScrollView } from 'react-native';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import Background from './Background';
import * as ImagePicker from 'expo-image-picker';
import { white } from './Constants';
import axios from 'axios';
import Config from './constants/Config';

const LaborSignup = (props: { navigation: { navigate: (arg0: string) => void; goBack: () => void; }; }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [cnic, setCnic] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [hidePassword, setHidePassword] = useState(true);
  const [hideConfirmPassword, setHideConfirmPassword] = useState(true);
  const [image, setImage] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [city, setCity] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const cities = ['Officers Colony', 'Basti', 'Taxila', 'Bahria Phase 1-5', 'Bahria Phase 5-7', 'Ammar Chok', 'Chaklala', 'I-8', 'G-9']; // Replace with your city list

  const showErrorModal = (message: React.SetStateAction<string>) => {
    setErrorMessage(message);
    setErrorModalVisible(true);
  };

  

  const handleCitySelection = (city: React.SetStateAction<string>) => {
    setCity(city);
    setShowDropdown(false);
  };

  const handlePress = async () => {
    // Validation checks
    // ...

    try {
      const { data } = await axios.post(`${Config.baseURL}/auth/createUser`, {
        name: name.charAt(0).toUpperCase() + name.slice(1),
        email,
        phoneNumber,
        cnic,
        password,
        confirmPassword,
        city,
      });
      if (data?.message === "Customer created successfully") {
        // Reset form fields
        // ...

      } else {
        props.navigation.navigate('LaborLogin'); // Navigating to CustomerLogin screen
      }
    } catch (error) {
      console.error('Error creating customer:', error); // Log the error to console for debugging
      setErrorMessage('Email already exists!');
      setModalVisible(true);
    }
  };

  // Animation setup
  const scaleValue = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.timing(scaleValue, {
      toValue: 0.9,
      duration: 100,
      easing: Easing.ease,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(scaleValue, {
      toValue: 1,
      duration: 100,
      easing: Easing.ease,
      useNativeDriver: true,
    }).start();
  };

  return (
    <Background>
      <View style={{ alignItems: 'flex-start', width: 360 }}>
        {/* Back Button */}
        <TouchableOpacity onPress={() => props.navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>

        <Text style={{ color: 'black', fontSize: 24, fontWeight: 'bold', marginTop: 30, marginLeft: 10, top: -20 }}>
          Create a new account
        </Text>
        <Text style={{ color: 'black', fontSize: 12, fontWeight: 'normal', marginBottom: 5, marginHorizontal: 15, top: -20 }}>
          Please fill the sign-up form here
        </Text>

        <View style={{ backgroundColor: '#00BF63', height: 470, width: 360, borderRadius: 50, marginTop: 60, paddingTop: 25, alignItems: 'center', top: -10 }}>
          {/* Image and Text */}
          <View style={{ alignItems: 'center' }}>
            <Image source={require('./asset/Logo/Logo.jpg')} style={{ width: 100, height: 100, borderRadius: 250, top: -70, left: 70 }} />
          </View>

          {/* Name Field */}
          <View style={styles.inputContainer}>
            <FontAwesome name="user" size={20} color={white} style={styles.icon} />
            <TextInput placeholder="Name/نام" placeholderTextColor={white} style={styles.input} onChangeText={setName} value={name} />
          </View>

          {/* Email Field */}
          <View style={styles.inputContainer}>
            <FontAwesome name="envelope" size={20} color={white} style={styles.icon} />
            <TextInput placeholder="Email/ای میل" placeholderTextColor={white} style={styles.input} keyboardType="email-address" onChangeText={setEmail} value={email} />
          </View>

          {/* Phone Number Field */}
          <View style={styles.inputContainer}>
            <FontAwesome name="phone" size={20} color={white} style={styles.icon} />
            <TextInput placeholder="Phone Number/فون نمبر" placeholderTextColor={white} style={styles.input} keyboardType="numeric" onChangeText={setPhoneNumber} value={phoneNumber} />
          </View>

          {/* CNIC Field */}
          <View style={styles.inputContainer}>
            <FontAwesome name="phone" size={20} color={white} style={styles.icon} />
            <TextInput placeholder="CNIC/شناختی کارڈ" placeholderTextColor={white} style={styles.input} keyboardType="numeric" onChangeText={setCnic} value={cnic} />
          </View>

          {/* Password Field */}
          <View style={styles.inputContainer}>
            <FontAwesome name="lock" size={20} color={white} style={styles.icon} />
            <TextInput placeholder="Password/پاس ورڈ" placeholderTextColor={white} style={styles.input} secureTextEntry={hidePassword} onChangeText={setPassword} value={password} />
            <TouchableOpacity onPress={() => setHidePassword(!hidePassword)} style={styles.toggle}>
              <FontAwesome name={hidePassword ? "eye-slash" : "eye"} size={20} color={white} />
            </TouchableOpacity>
          </View>

          {/* Confirm Password Field */}
          <View style={styles.inputContainer}>
            <FontAwesome name="lock" size={20} color={white} style
={styles.icon} />
<TextInput placeholder="Confirm Password/پاس ورڈ" placeholderTextColor={white} style={styles.input} secureTextEntry={hideConfirmPassword} onChangeText={setConfirmPassword} value={confirmPassword} />
<TouchableOpacity onPress={() => setHideConfirmPassword(!hideConfirmPassword)} style={styles.toggle}>
  <FontAwesome name={hideConfirmPassword ? "eye-slash" : "eye"} size={20} color={white} />
</TouchableOpacity>
</View>

{/* City Selection */}
<View style={styles.inputContainer}>
<TouchableOpacity onPress={() => setShowDropdown(!showDropdown)} style={styles.dropdownButton}>
  <FontAwesome name="map-marker" size={20} color={white} style={styles.icon} />
  <Text style={styles.dropdownText}>{city || 'Select Area/علاقہ منتخب کریں'}</Text>
  <FontAwesome name={showDropdown ? "chevron-up" : "chevron-down"} size={20} color={white} />
</TouchableOpacity>
</View>
{showDropdown && (
<ScrollView style={styles.dropdown}>
  {cities.map((cityName, index) => (
    <TouchableOpacity key={index} onPress={() => handleCitySelection(cityName)} style={styles.dropdownItem}>
      <Text style={styles.dropdownItemText}>{cityName}</Text>
    </TouchableOpacity>
  ))}
</ScrollView>
)}

{/* Signup Button */}
<Animated.View style={{ transform: [{ scale: scaleValue }], width: 150, height: 50, top: -60, }}>
<TouchableOpacity
  style={styles.signupButton}
  onPressIn={handlePressIn}
  onPressOut={handlePressOut}
  onPress={handlePress}
>
  <Text style={styles.signupButtonText}>Sign Up</Text>
</TouchableOpacity>
</Animated.View>

{/* Modal for errors */}
<Modal
visible={modalVisible}
animationType="slide"
transparent={true}
onRequestClose={() => setModalVisible(false)}
>
<View style={styles.modalContainer}>
  <View style={styles.modalContent}>
    <Text style={styles.modalText}>{errorMessage}</Text>
    <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
      <Text style={styles.closeButtonText}>Close</Text>
    </TouchableOpacity>
  </View>
</View>
</Modal>

{/* Error Modal */}
<Modal visible={errorModalVisible} animationType="slide" transparent={true}>
<View style={styles.modalContainer}>
  <View style={styles.modalContent}>
    <Text style={styles.modalText}>{errorMessage}</Text>
    <TouchableOpacity onPress={() => setErrorModalVisible(false)} style={styles.closeButton}>
      <Text style={styles.closeButtonText}>Close</Text>
    </TouchableOpacity>
  </View>
</View>
</Modal>
</View>
</View>
</Background>
);
};

const styles = StyleSheet.create({
inputContainer: {
flexDirection: 'row',
alignItems: 'center',
width: 300,
borderRadius: 5,
borderColor: 'white',
borderWidth: 1,
marginVertical: 10,
top: -70,
},
icon: {
paddingHorizontal: 10,
},
input: {
flex: 1,
fontSize: 10,
height: 28,
color: white,
paddingHorizontal: 10,
backgroundColor: 'transparent',
},
toggle: {
paddingHorizontal: 10,
},
dropdownButton: {
flexDirection: 'row',
alignItems: 'center',
flex: 1,
},
dropdownText: {
color: white,
fontSize: 10,
height: 28,
paddingHorizontal: 10,
textAlignVertical: 'center',
},
dropdown: {
maxHeight: 130,
width: 300,
backgroundColor: 'white',
borderRadius: 5,
borderColor: 'black',
borderWidth: 1,
position: 'absolute',
top: 400,
}, 
dropdownItem: {
padding: 10,
borderBottomColor: 'black',
borderBottomWidth: 1,
},
dropdownItemText: {
fontSize: 12,
color: 'black',
},
signupButton: {
backgroundColor: '#00BF63',
borderRadius: 10,
alignItems: 'center',
justifyContent: 'flex-end',
paddingVertical: 10,
top:120,
},
signupButtonText: {
color: 'white',
fontWeight: 'bold',
fontSize: 16,
},
modalContainer: {
flex: 1,
justifyContent: 'center',
alignItems: 'center',
backgroundColor: 'rgba(0, 0, 0, 0.5)',
},
modalContent: {
backgroundColor: 'white',
borderRadius: 10,
padding: 20,
width: 300,
alignItems: 'center',
},
modalText: {
fontSize: 16,
marginBottom: 20,
},
closeButton: {
backgroundColor: '#00BF63',
borderRadius: 10,
paddingVertical: 10,
paddingHorizontal: 
20,
},
closeButtonText: {
  color: 'white',
  fontSize: 16,
  fontWeight: 'bold',
},
backButton: {
  position: 'absolute',
  top: -30,
  left: 20,
  zIndex: 1,
},
});

export default LaborSignup;
