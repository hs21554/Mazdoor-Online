import { View, Text, TouchableOpacity } from 'react-native';
import React from 'react';

interface BtnProps {
  bgColor: string; // Explicitly specify the type of bgColor
  btnLabel: string;
  textColor: string;
  Press: () => void;
}

export default function Btn({ bgColor, btnLabel, textColor, Press }: BtnProps) {
  return (
    <TouchableOpacity
      onPress={Press}
      style={{
        backgroundColor: bgColor,
        borderRadius: 0,
        alignItems: 'center',
        width: 395,
        paddingVertical: 5,
        marginVertical: 10
      }}>
      <Text style={{ color: textColor, fontSize: 25, fontWeight: 'bold' }}>
        {btnLabel}
      </Text>
    </TouchableOpacity>
  );
}


