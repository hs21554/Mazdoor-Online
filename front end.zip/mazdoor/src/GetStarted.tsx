import React, { useRef, useEffect } from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet, Animated } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const GetStarted = (props: { navigation: { navigate: (arg0: string) => void; }; }) =>  {
  const navigation = useNavigation();
  const animatedValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const moveFront = () => {
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 1000, // Adjust animation speed as needed
        useNativeDriver: true,
      }).start(() => moveBack());
    };

    const moveBack = () => {
      Animated.timing(animatedValue, {
        toValue: 0,
        duration: 1000, // Adjust animation speed as needed
        useNativeDriver: true,
      }).start(() => moveFront());
    };

    moveFront(); // Start animation immediately

    const intervalId = setInterval(() => {
      moveFront();
    }, 2000); // Move every 2 seconds

    return () => clearInterval(intervalId);
  }, []);

  const buttonScale = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.1], // You can adjust the scaling factor as needed
  });

  return (
    <View style={styles.container}>
      <View style={styles.greenBox}>
        <View style={styles.imageContainer}>
          <Image
            source={require('./asset/Logo/Logo.jpg')}
            style={styles.image}
          />
          <Text style={styles.welcomeText}>Welcome to</Text>
          <Text style={styles.welcomeText}>Mazdoor Online</Text>
          <TouchableOpacity style={[styles.button, { transform: [{ scale: buttonScale }] }]} onPress={() => props.navigation.navigate("Home")}>
            <Text style={styles.buttonText}>Get Started</Text>
            <Image
              source={require('./asset/Logo/arrow.png')}
              style={styles.arrowIcon}
            />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  greenBox: {
    backgroundColor: '#00BF63',
    width: 350,
    height: 700,
    top: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 28,
    marginBottom: 20,
  },
  imageContainer: {
    width: 330,
    height: 400,
    top: -80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: '100%', // Adjusted height for image
    resizeMode: 'contain',
  },
  welcomeText: {
    top: -105, // Adjust as needed
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
  },
  button: {
    bottom: -20,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    paddingHorizontal: 60,
    paddingVertical: 10,
    borderRadius: 28,
  },
  buttonText: {
    marginRight: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },
  arrowIcon: {
    width: 20,
    left: 20,
    alignSelf: 'center',
    height: 20,
    resizeMode: 'contain',
  },
});

export default GetStarted;
