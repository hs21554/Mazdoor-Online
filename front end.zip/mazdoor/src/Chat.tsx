import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { GiftedChat, IMessage, Bubble } from 'react-native-gifted-chat';


const Chat: React.FC = () => {
  const [messages, setMessages] = useState<IMessage[]>([]);

  const handleEdit = () => {
    // Handle edit action
  };

  const onSend = useCallback((messages: IMessage[] = []) => {
    setMessages((previousMessages) => GiftedChat.append(previousMessages, messages));
  }, []);

  const openWhatsApp = () => {
    // Replace '1234567890' with the actual WhatsApp number
    Linking.openURL('whatsapp://send?phone=+923185658477');
  };

  const makeCall = () => {
    // Replace '1234567890' with the actual phone number
    Linking.openURL('tel:03185658477');
  };

  return (
    <View style={styles.container}>
      <View style={styles.laborProfileContainer}>
        {/* Chat Heading */}
  
        {/* Existing code */}
        <View style={styles.greenBox}></View>
        
        <View style={styles.nameContainer}>
          <Feather name="user" size={20} color="black" />
          <Text style={styles.nameText}> Ali Khan</Text>
        </View>
        <View style={styles.locationContainer}>
          <Feather name="map-pin" size={20} color="black" />
          <Text style={styles.locationText}>  I-8</Text>
        </View>
        <View style={styles.reviewsContainer}>
          <Feather name="star" size={20} color="black" />
          <Text style={styles.reviewsText}> 4.8</Text>
        </View>
        <View style={styles.skillsContainer}>
          <Feather name="award" size={20} color="black" />
          <Text style={styles.skillsText}> Painter</Text>
        </View>
        <TouchableOpacity style={styles.callContainer} onPress={makeCall}>
          <Feather name="phone" size={20} color="black" />
          <Text style={styles.callText}> Call</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.whatsappContainer} onPress={openWhatsApp}>
          <Feather name="message-circle" size={20} color="white" />
          <Text style={styles.whatsappText}> WhatsApp</Text>
        </TouchableOpacity>
        
        
        
        <View style={styles.logoContainer}>
          <Image
            source={require('./asset/Skills/painter.png')} // Replace 'path_to_your_logo.png' with the actual path to your logo image
            style={styles.logoImage}
          />
        </View>
        {/* Chat Box */}
        
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    top:69,
    flex: 1,
    backgroundColor: '#12202F',
    alignItems: 'center',
    justifyContent: 'center',
  },
  laborProfileContainer: {
    width: 400,
    height: 900,
    backgroundColor: 'white',
    borderRadius: 0, // Rectangular shape
    position: 'relative',
    marginTop: 20,
  },
  greenBox: {
    position: 'absolute',
    top: 310,
    left: 50,
    width: 302,
    height: 300,
    backgroundColor: '#00BF63',
    borderRadius: 28,
  },
 
  locationContainer: {
    position: 'absolute',
    top: 110,
    left: 211,
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    color: 'black',
    fontSize: 13,
    fontFamily: 'Roboto',
    fontWeight: '400',
  },
  nameContainer: {
    position: 'absolute',
    top: 80,
    left: 211,
    flexDirection: 'row',
    alignItems: 'center',
  },
  nameText: {
    color: 'black',
    fontSize: 13,
    fontFamily: 'Roboto',
    fontWeight: '400',
  },
  reviewsContainer: {
    position: 'absolute',
    top: 140,
    left: 212,
    flexDirection: 'row',
    alignItems: 'center',
  },
  reviewsText: {
    color: 'black',
    fontSize: 13,
    fontWeight: '400',
  },
  skillsContainer: {
    position: 'absolute',
    top: 170,
    left: 213,
    flexDirection: 'row',
    alignItems: 'center',
  },
  skillsText: {
    color: 'black',
    fontSize: 13,
    fontWeight: '400',
  },
  callContainer: {
    position: 'absolute',
    top: 390,
    left: 111,
    width: 180,
    height: 40,
    backgroundColor: 'white',
    borderRadius: 0, // Rectangular shape
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center horizontally
    borderWidth: 1,
    borderColor: 'black',
  },
  callText: {
    color: 'black',
    fontSize: 15,
    fontFamily: 'Roboto',
    fontWeight: '800',
  },
  whatsappContainer: {
    position: 'absolute',
    top: 500,
    left: 111,
    width: 180,
    height: 40,
    backgroundColor: '#27D266',
    borderRadius: 0, // Rectangular shape
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center horizontally
    borderWidth: 1,
    borderColor: 'black',
  },
  whatsappText: {
    color: 'white',
    fontSize: 15,
    fontFamily: 'Roboto',
    fontWeight: '800',
  },
  smsContainer: {
    position: 'absolute',
    top: 250,
    left: 210,
    width: 117,
    height: 31,
    backgroundColor: 'white',
    borderRadius: 0, // Rectangular shape
    flexDirection
    : 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center horizontally
    borderWidth: 1,
    borderColor: 'black',
  },
  smsText: {
    color: 'black',
    fontSize: 15,
    fontFamily: 'Roboto',
    fontWeight: '800',
  },
  logoContainer: {
    position: 'absolute',
    top: 80,
    left: 56,
    width: 120,
    height: 121,
    justifyContent: 'center', // Center vertically
    alignItems: 'center', // Center horizontally
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 70, // Make it a circle
  },
  chatContainer: {
    position: 'absolute',
    top: 340,
    borderRadius: 20,
    borderColor: 'black',
    borderWidth: 1, // Add a border
    height: 430,
    width: 250,
    left: 75,
    backgroundColor: 'white', // Use a light green color similar to WhatsApp
  },
});

export default Chat;
