import React, { useState } from 'react';
import { View, StyleSheet, Text, Image, Dimensions, TouchableOpacity, ScrollView, Button } from 'react-native';
import CheckBox from '@react-native-community/checkbox';
import Background from './Background';
import { black, green } from './Constants';

const { width } = Dimensions.get('window');

const TermsAndConditions = (props: { navigation: { navigate: (arg0: string) => void; }; }) => {
  const [isChecked, setIsChecked] = useState(false);

  const handleAccept = () => {
    if (isChecked) {
      props.navigation.navigate("Home");
    }
  };

  const handleCancel = () => {
    // Do nothing, just stay on the current screen
  };

  return (
    <Background>
      <View style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <Text style={styles.termsTitle}>Terms and Conditions</Text>
          <Text style={styles.termsText}>
            // Your detailed terms and conditions text goes here.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis tincidunt urna nec odio malesuada feugiat. 
            Vivamus a pharetra arcu. Praesent sit amet vehicula justo. Donec at nibh nec arcu luctus ullamcorper. 
            Integer varius elit at nisi egestas, et auctor tortor feugiat. 
            // Add more terms and conditions content as needed.
          </Text>
        </ScrollView>
        <View style={styles.checkboxContainer}>
          <CheckBox
            value={isChecked}
            onValueChange={setIsChecked}
          />
          <Text style={styles.checkboxLabel}>I agree to the Terms and Conditions</Text>
        </View>
        <View style={styles.buttonContainer}>
          <Button title="Accept" onPress={handleAccept} disabled={!isChecked} />
          <Button title="Cancel" onPress={handleCancel} />
        </View>
      </View>
    </Background>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#00BF63",
    width: 400,
  },
  scrollContainer: {
    padding: 20,
  },
  termsTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
  },
  termsText: {
    fontSize: 16,
    textAlign: 'justify',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
  },
  checkboxLabel: {
    marginLeft: 8,
    fontSize: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
});

export default TermsAndConditions;
