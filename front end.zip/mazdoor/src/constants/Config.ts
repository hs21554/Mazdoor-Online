export default {
  baseURL: 'http://192.168.1.71:4500/api/v1',
};
